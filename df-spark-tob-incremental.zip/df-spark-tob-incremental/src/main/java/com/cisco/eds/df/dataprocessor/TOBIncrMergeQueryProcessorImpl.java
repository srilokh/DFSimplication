package com.cisco.eds.df.dataprocessor;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;

import com.cisco.eds.df.dataextractor.INCTobQueries;
import com.cisco.eds.df.dataextractor.TOBIncrMergeQueries;;



public class TOBIncrMergeQueryProcessorImpl {
	
	public void generateBaseTOBIncrMergeData( HiveContext hiveContext, JavaSparkContext sc) {

		/*Changes started 03-03-2017*/
		DataFrame WI_LATEST_LINE_IDENTIFICATION_FLG_DF = hiveContext.sql(TOBIncrMergeQueries.WI_LATEST_LINE_IDENTIFICATION_FLG_QUOTE);
		WI_LATEST_LINE_IDENTIFICATION_FLG_DF.registerTempTable("WI_LATEST_LINE_IDENTIFICATION_FLG");	
		
		DataFrame LOAD_INC_TO_HISTORY_DF=hiveContext.sql(TOBIncrMergeQueries.LOAD_INC_TO_HISTORY);
		LOAD_INC_TO_HISTORY_DF.registerTempTable("LOAD_INC_TO_HISTORY_DF");
		hiveContext.sql("insert into table service_ibsa.total_opportunity_base select * from LOAD_INC_TO_HISTORY_DF");
		/*Changes Ended 03-03-2017*/
		DataFrame total_opportunity_base_df2 = hiveContext.sql(TOBIncrMergeQueries.total_opportunity_base_LOAD2);
		//total_opportunity_base_df2.registerTempTable("total_opportunity_base");
	   // hiveContext.sql("insert overwrite table service_ibsa.total_opportunity_base select * from total_opportunity_base");
	   total_opportunity_base_df2.write().mode(SaveMode.Overwrite).parquet("/app/DFSimplification/data_enablement/service_ibsa/total_opportunity_base_merge");
	
		System.out.println("========= Done with TOB =========");
	
	}

}

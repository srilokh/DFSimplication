package com.cisco.eds.df.dataprocessor;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;

import com.cisco.dfs.jobcontrol.impl.DFSJobControlImpl;
import com.cisco.dfs.jobcontrol.interfaces.DFSJobControl;
import com.cisco.eds.df.dataextractor.DFConstants;
import com.cisco.eds.df.dataextractor.TOBIncrBaseQueries;;



public class TOBIncrQueryProcessorImpl {
	
	public void generateBaseTOBIncrData( HiveContext hiveContext, JavaSparkContext sc) {
		DFSJobControl jobControl = new DFSJobControlImpl();
		String PV_POS_TRANSACTION_LINE_LAST_EXTRACT_DATE="";
		try {
			
			PV_POS_TRANSACTION_LINE_LAST_EXTRACT_DATE=jobControl.getLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_POS_TRANSACTION_LINE");
			System.out.println("LastExtractDate from Job Control for PV_POS_TRANSACTION_LINE " + PV_POS_TRANSACTION_LINE_LAST_EXTRACT_DATE);

			}  catch (Exception e1) {
			System.out.println("Failed in Retrieving the Last Extract Date from Job Control Table");
			e1.printStackTrace();
			System.exit(0);
			}
		 String PV_POS_TRANSACTION_LINE_INCRE = "select "
				+" BK_POS_TRANSACTION_ID_INT,"
				 +" EDW_UPDATE_DATETIME"
				+" from "+DFConstants.Db+".PV_POS_TRANSACTION_LINE PTL"
				+" where unix_timestamp(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_POS_TRANSACTION_LINE_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";
		
		DataFrame PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR = hiveContext.sql(TOBIncrBaseQueries.PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR);
		PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR.registerTempTable("PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR");
		
		//DataFrame TOB_INCREMENTAL_PSCLTS = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_PSCLTS);//remove this write PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR //Madhav Commented 
		PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc");   //Madhav Commented
		
		System.out.println("Done PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR");  
		
	/*	DFSJobControl jobControl = new DFSJobControlImpl();

		String lastExtractDate = jobControl.getLastExtractdate("XXCSS_IBRECON_AUDIT_LOG");

		
		DataFrame PV_SVC_CNTRCT_TECH_SERVICES_INCR = hiveContext.sql(TOBIncrBaseQueries.getPV_SVC_CNTRCT_TECH_SERVICES_INCRQuery(lastExtractDate));
	*/	
		
		
		DataFrame PV_SVC_CNTRCT_TECH_SERVICES_INCR = hiveContext.sql(TOBIncrBaseQueries.PV_SVC_CNTRCT_TECH_SERVICES_INCR);
		sc.broadcast(PV_SVC_CNTRCT_TECH_SERVICES_INCR);
		
		PV_SVC_CNTRCT_TECH_SERVICES_INCR.persist();
		
		PV_SVC_CNTRCT_TECH_SERVICES_INCR.take(1);
		
		PV_SVC_CNTRCT_TECH_SERVICES_INCR.registerTempTable("PV_SVC_CNTRCT_TECH_SERVICES_INCR");
		
		DataFrame TOB_INCREMENTAL_TOB_PSCTS = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_TOB_PSCTS);
		TOB_INCREMENTAL_TOB_PSCTS.registerTempTable("TOB_INCREMENTAL_TOB_PSCTS");
		
		TOB_INCREMENTAL_TOB_PSCTS.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc"); //Madhav Commented
		
		PV_SVC_CNTRCT_TECH_SERVICES_INCR.unpersist();
		
		System.out.println("Done PV_SVC_CNTRCT_TECH_SERVICES_INCR"); 
		
		/********/
		
		
		/********/
		
		DataFrame PV_POS_TRANSACTION_LINE_INCR = hiveContext.sql(PV_POS_TRANSACTION_LINE_INCRE);
				
		sc.broadcast(PV_POS_TRANSACTION_LINE_INCR);
		
		PV_POS_TRANSACTION_LINE_INCR.persist();
		
		PV_POS_TRANSACTION_LINE_INCR.take(1);
		
		PV_POS_TRANSACTION_LINE_INCR.registerTempTable("PV_POS_TRANSACTION_LINE_INCR");
		String maxUpdatedDate_PV_POS_TRANSACTION = hiveContext.sql("select max(from_unixtime(unix_timestamp(EDW_UPDATE_DATETIME),'yyyy-MM-dd HH:mm:ss')) from PV_POS_TRANSACTION_LINE_INCR").takeAsList(1).get(0).getString(0);
		
		DataFrame TOB_INCREMENTAL_NIP_PPTL = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_NIP_PPTL);
		TOB_INCREMENTAL_NIP_PPTL.registerTempTable("TOB_INCREMENTAL_NIP_PPTL");
		
		TOB_INCREMENTAL_NIP_PPTL.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc"); //Madhav Commented
		
		PV_POS_TRANSACTION_LINE_INCR.unpersist();
		
		System.out.println("Done PV_POS_TRANSACTION_LINE_INCR"); 
		
		/********/
		
		DataFrame TOB_INCREMENTAL_PVIP = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_PVIP);
		TOB_INCREMENTAL_PVIP.registerTempTable("TOB_INCREMENTAL_PVIP");
		
		TOB_INCREMENTAL_PVIP.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc"); //Madhav Commented
		System.out.println("Done TOB_INCREMENTAL_PVIP");
		
		/*//Madhav Added
		DataFrame TOB_INCREMENTAL_UNION = PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR.unionAll(TOB_INCREMENTAL_TOB_PSCTS).unionAll(TOB_INCREMENTAL_NIP_PPTL).unionAll(TOB_INCREMENTAL_PVIP);
		TOB_INCREMENTAL_UNION.registerTempTable("TOB_INCREMENTAL_UNION");
		
		hiveContext.sql("insert into table dfprd.tob_incremental_source select * from TOB_INCREMENTAL_UNION"); */
		
		
		DataFrame TOB_INCREMENTAL_FINAL = hiveContext.sql("SELECT DISTINCT SK_INSTANCE_ID_INT from dfprd.tob_incremental_source"); //Madhav Changed table name
		//TOB_INCREMENTAL_FINAL.write().saveAsTable("dfprd.tob_incremental_table_distinct");
		TOB_INCREMENTAL_FINAL.registerTempTable("tob_incremental_table_distinct");
		System.out.println("Done tob_incremental_table_distinct"); 
		
		/*************/
		DataFrame N_INSTALLED_PRODUCT_DF = hiveContext.sql(TOBIncrBaseQueries.N_INSTALLED_PRODUCT_temp);
		N_INSTALLED_PRODUCT_DF.registerTempTable("N_INSTALLED_PRODUCT_temp");
		
		DataFrame N_INSTALLED_PRODUCT_INCR_FILTERED = hiveContext.sql(TOBIncrBaseQueries.N_INSTALLED_PRODUCT_INCR_FILTERED);
		N_INSTALLED_PRODUCT_INCR_FILTERED.registerTempTable("N_INSTALLED_PRODUCT_INCR_FILTERED");
		
		DataFrame TOB_FINAL = hiveContext.sql(TOBIncrBaseQueries.TOB_FINAL);
		TOB_FINAL.write().mode(SaveMode.Overwrite).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc_final");
		//TOB_FINAL.write().saveAsTable("dfprd.TOB_INCR");
		System.out.println("Done TOB_INCREMENTAL_FINAL");
		
		
		try {
			if(maxUpdatedDate_PV_POS_TRANSACTION != null){
			jobControl.updateLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_POS_TRANSACTION_LINE",maxUpdatedDate_PV_POS_TRANSACTION);
			}else{
			System.out.println("Max last Update Date is NULL for PV_POS_TRANSACTION_LINE or No Incremental Records"); 
			}
			
			} catch (Exception e1) {
			System.out.println("Failed to update the last extract date to job control");
			e1.printStackTrace();
			}
		
	}

}

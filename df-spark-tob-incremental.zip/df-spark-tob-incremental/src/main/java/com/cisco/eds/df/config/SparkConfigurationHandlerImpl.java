package com.cisco.eds.df.config;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.hive.HiveContext;


public class SparkConfigurationHandlerImpl implements SparkConfigurationHandler {

	private static final long serialVersionUID = 1L;

	private SparkConf sparkConf;
	
	private JavaSparkContext javaSparkContext;
	
	private HiveContext hiveContext;
	
	private SQLContext sqlContext;
	
	public void intialize() {
		
		sparkConf = new SparkConf();
		sparkConf.set("spark.sql.hive.metastore.version", "1.2.0");
		sparkConf.set("spark.sql.hive.metastore.sharedPrefixes", "com.mysql.jdbc,org.postgresql,com.microsoft.sqlserver,oracle.jdbc,com.mapr.fs.shim.LibraryLoader,com.mapr.security.JNISecurity,com.mapr.fs.jni");
		sparkConf.set("hive.support.sql11.reserved.keywords", "false");
		sparkConf.set("spark.sql.hive.version", "1.2.1");
		sparkConf.set("spark.sql.hive.metastore.jars", "/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop:/opt/mapr/hadoop/hadoop-2.7.0/share/hadoop/common/lib/*:/opt/mapr/hadoop/hadoop-2.7.0/share/hadoop/common/*:/opt/mapr/hadoop/./hadoop-2.7.0/share/hadoop/mapreduce/*:/opt/mapr/hadoop/hadoop-2.7.0/share/hadoop/yarn/*:/opt/mapr/hive/hive-1.2/lib/*");
		
		javaSparkContext = new JavaSparkContext(sparkConf);
		
		hiveContext = new org.apache.spark.sql.hive.HiveContext(javaSparkContext);
		
		sqlContext = new org.apache.spark.sql.SQLContext(javaSparkContext);
	}

	public SparkConf getSparkConf() {
		return sparkConf;
	}

	public JavaSparkContext getSparkContext() {
		return javaSparkContext;
	}

	public HiveContext getHiveContext() {
		return hiveContext;
	}

	public SQLContext getSQLContext() {
		
		return sqlContext;
	}

}

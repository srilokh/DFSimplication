package com.cisco.eds.df.dataprocessor;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;

import com.cisco.dfs.jobcontrol.impl.DFSJobControlImpl;
import com.cisco.dfs.jobcontrol.interfaces.DFSJobControl;
import com.cisco.eds.df.dataextractor.DFConstants;
import com.cisco.eds.df.dataextractor.TOBIncrBaseQueries;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class TOBIncrQueryProcessorImplParll {
	
	public void generateBaseTOBIncrData( HiveContext hiveContext, JavaSparkContext sc) {



DFSJobControl jobControl = new DFSJobControlImpl();



		String PV_BKGS_MEASURE_LAST_EXTRACT_DATE="";
		String PV_BKGS_MEASURE_CURR_QTR_LAST_EXTRACT_DATE=""; 
		String PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE="";
		String PV_PMC_PTNR_MANUAL_OVERRIDE_LAST_EXTRACT_DATE="";
		
		try {
			PV_BKGS_MEASURE_LAST_EXTRACT_DATE = jobControl.getLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_MEASURE");
			PV_BKGS_MEASURE_CURR_QTR_LAST_EXTRACT_DATE = jobControl.getLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_MEASURE_CURR_QTR");
			PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE=jobControl.getLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_CHNL_MEASURE");
			PV_PMC_PTNR_MANUAL_OVERRIDE_LAST_EXTRACT_DATE=jobControl.getLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_PMC_PTNR_MANUAL_OVERRIDE");
			
			//lastExtractDate_Contacts = jobControl.getLastExtractDate("N_SERVICE_CONTRACT#OKC_CONTACTS");

			System.out.println("LastExtractDate from Job Control for PV_BKGS_MEASURE " + PV_BKGS_MEASURE_LAST_EXTRACT_DATE);
			System.out.println("LastExtractDate from Job Control for PV_BKGS_MEASURE_CURR_QTR " + PV_BKGS_MEASURE_CURR_QTR_LAST_EXTRACT_DATE);
			System.out.println("LastExtractDate from Job Control for PV_BKGS_CHANL_MEASURE " + PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE);
			System.out.println("LastExtractDate from Job Control for MANUAL_OVERRIDE " + PV_PMC_PTNR_MANUAL_OVERRIDE_LAST_EXTRACT_DATE);
			
			//System.out.println("LastExtractDate from Job Control for OKC_CONTACTS " + lastExtractDate_Contacts);

			}  catch (Exception e1) {
			System.out.println("Failed in Retrieving the Last Extract Date from Job Control Table");
			e1.printStackTrace();
			System.exit(0);
			}
		
		if(PV_BKGS_MEASURE_LAST_EXTRACT_DATE!=null && PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE!=null)
		{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1;
		try {
			date1 = sdf.parse(PV_BKGS_MEASURE_LAST_EXTRACT_DATE);
			Date date2 = sdf.parse(PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE);
	        System.out.println(" PV_BKGS_MEASURE date1 : " + sdf.format(date1));
	        System.out.println("PV_BKGS_CHANL_MEASURE date2 : " + sdf.format(date2));

	        if (date1.compareTo(date2) > 0) {
	        	PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE=date2.toString();
	        } else if (date1.compareTo(date2) < 0) {
	        	PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE=date1.toString();
	        } else  {
	        	PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE=date1.toString();
	        }
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        


		}
		
		  String PV_BKGS_MEASURE_DF1 = "select "
				+" SALES_CHANNEL_CODE,"
				+" ADJUSTMENT_TYPE_CODE,SERVICE_FLG,TRANSACTION_DATETIME,"
				+" BOOKINGS_MEASURE_KEY, BOOKINGS_PROCESS_DATE, SALES_ORDER_LINE_KEY,"
				+" BKGS_MEASURE_TRANS_TYPE_CODE,EDW_UPDATE_DATETIME,sales_territory_key,BK_POS_TRANSACTION_ID_INT"
				+" from sales_tdprod_datalakepvwdb.PV_BKGS_MEASURE"
				+" where unix_timestamp(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_BKGS_MEASURE_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";
		   String PV_BKGS_MEASURE_DF2 = "select SALES_CHANNEL_CODE,ADJUSTMENT_TYPE_CODE,"
					+" SERVICE_FLG,TRANSACTION_DATETIME,BOOKINGS_MEASURE_KEY, BOOKINGS_PROCESS_DATE, SALES_ORDER_LINE_KEY,"
					+" BKGS_MEASURE_TRANS_TYPE_CODE,EDW_UPDATE_DATETIME,sales_territory_key,BK_POS_TRANSACTION_ID_INT"
					+" from sales_tdprod_datalakepvwdb.PV_BKGS_MEASURE_CURR_QTR"
				+" where unix_timestamp(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_BKGS_MEASURE_CURR_QTR_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";
		   
		    String PV_BKGS_MEASURE_INCRE = "select "
					+" SALES_ORDER_LINE_KEY,"
					+" BKGS_MEASURE_TRANS_TYPE_CODE"
					+" from "+DFConstants.Db+".PV_BKGS_MEASURE_joinFilter NBM"
					+" where trim(NBM.BKGS_MEASURE_TRANS_TYPE_CODE) IN  ('ERP','AR','POS') AND NBM.SALES_ORDER_LINE_KEY>0 " 
					+" And unix_timestamp(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_BKGS_MEASURE_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";
		    
		    String PV_BOOKINGS_MEASURE_INCRE_U = "select "
					+" BOOKINGS_MEASURE_KEY,"
					+" BOOKINGS_PROCESS_DATE,"
					+" BKGS_MEASURE_TRANS_TYPE_CODE,"
					+" SALES_ORDER_LINE_KEY,"
					+" EDW_UPDATE_DATETIME"
					+" from "+DFConstants.Db+".PV_BKGS_MEASURE_joinFilter NBM"
					+" WHERE unix_timestamp(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_BKGS_CHNL_MEASURE_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";
		    
		     String PV_PMC_PTNR_MANUAL_OVERRIDE_INCRE = "select "
					+" ERP_CUST_ACCOUNT_LOCATION_KEY,"
					+" SOURCE_DELETED_FLG,"
					+" MAPPING_METHOD_CD,"
					+" PERFORMANCE_METRIC_ENGINE_CD,"
					+" EDW_UPDATE_DTM"
					+" from "+DFConstants.Db+".PV_PMC_PTNR_MANUAL_OVERRIDE NPMC,"
					+" (select max(A.last_extract_date) as last_extract_date from dfprd.JOB_CONTROL_DF_TOB A where A.table_name = 'N_PMC_PTNR_MANUAL_OVERRIDE')abc"
					+" where "
					+" NPMC.SOURCE_DELETED_FLG = 'N' "
					+" AND NPMC.MAPPING_METHOD_CD = 'MANUAL_OVERRIDE' "
					+" AND NPMC.PERFORMANCE_METRIC_ENGINE_CD = 'INCLUDED' "
					+" AND NPMC.ERP_CUST_ACCOUNT_LOCATION_KEY>0"
		            +" And unix_timestamp(EDW_UPDATE_DTM,'yyyy-MM-dd HH:mm:ss') > unix_timestamp('"+PV_PMC_PTNR_MANUAL_OVERRIDE_LAST_EXTRACT_DATE+"','yyyy-MM-dd HH:mm:ss')";

			

				
				
		DataFrame PV_BKGS_MEASURE_temp1 = hiveContext.sql(PV_BKGS_MEASURE_DF1);
		PV_BKGS_MEASURE_temp1.write().mode(SaveMode.Overwrite).saveAsTable("dfprd.PV_BKGS_MEASURE_joinFilter");
		


		String maxUpdatedDate_Bkgs_Measure = hiveContext.sql("select max(from_unixtime(unix_timestamp(EDW_UPDATE_DATETIME),'yyyy-MM-dd HH:mm:ss')) from dfprd.PV_BKGS_MEASURE_joinFilter").takeAsList(1).get(0).getString(0);
		
		DataFrame PV_BKGS_MEASURE_temp2 = hiveContext.sql(PV_BKGS_MEASURE_DF2);
		PV_BKGS_MEASURE_temp2.registerTempTable("PV_BKGS_MEASURE_CURR_QTR");
		PV_BKGS_MEASURE_temp2.write().mode(SaveMode.Append).saveAsTable("dfprd.PV_BKGS_MEASURE_joinFilter");
		String maxUpdatedDate_Bkgs_Measure_CURR = hiveContext.sql("select max(from_unixtime(unix_timestamp(EDW_UPDATE_DATETIME),'yyyy-MM-dd HH:mm:ss')) from PV_BKGS_MEASURE_CURR_QTR").takeAsList(1).get(0).getString(0);		
	
		
	/*	DFSJobControl jobControl = new DFSJobControlImpl();

		String lastExtractDate = jobControl.getLastExtractdate("XXCSS_IBRECON_AUDIT_LOG");

		
		DataFrame PV_SVC_CNTRCT_TECH_SERVICES_INCR = hiveContext.sql(TOBIncrBaseQueries.getPV_SVC_CNTRCT_TECH_SERVICES_INCRQuery(lastExtractDate));
	*/	
		
		
		
		/********/
		
		
		/********/
		
		DataFrame PV_BKGS_MEASURE_INCR = hiveContext.sql(PV_BKGS_MEASURE_INCRE);
				
		sc.broadcast(PV_BKGS_MEASURE_INCR);
		
		PV_BKGS_MEASURE_INCR.persist();
		
		PV_BKGS_MEASURE_INCR.take(1);
		
		PV_BKGS_MEASURE_INCR.registerTempTable("PV_BKGS_MEASURE_INCR");
		
		DataFrame TOB_INCREMENTAL_PBKGSM = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_PBKGSM);
		TOB_INCREMENTAL_PBKGSM.registerTempTable("TOB_INCREMENTAL_PBKGSM");
		
		//TOB_INCREMENTAL_PBKGSM.write().mode(SaveMode.Overwrite).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc"); //Madhav Commented
		
		PV_BKGS_MEASURE_INCR.unpersist();
		
		System.out.println("Done PV_BKGS_MEASURE_INCR");
		
		/********/
		
		/********/
		
		DataFrame PV_BOOKINGS_MEASURE_INCR_U = hiveContext.sql(PV_BOOKINGS_MEASURE_INCRE_U);
				
		sc.broadcast(PV_BOOKINGS_MEASURE_INCR_U);
		
		PV_BOOKINGS_MEASURE_INCR_U.persist();
		
		PV_BOOKINGS_MEASURE_INCR_U.take(1);
		
		PV_BOOKINGS_MEASURE_INCR_U.registerTempTable("PV_BOOKINGS_MEASURE_INCR_U");
		String maxUpdatedDate_Bkgs_channel_Measure = hiveContext.sql("select max(from_unixtime(unix_timestamp(EDW_UPDATE_DATETIME),'yyyy-MM-dd HH:mm:ss')) from PV_BOOKINGS_MEASURE_INCR_U").takeAsList(1).get(0).getString(0);
		
		DataFrame TOB_INCREMENTAL_NIP_PBKGSCM = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_NIP_PBKGSCM);
		TOB_INCREMENTAL_NIP_PBKGSCM.registerTempTable("TOB_INCREMENTAL_NIP_PBKGSCM");
		
		//TOB_INCREMENTAL_NIP_PBKGSCM.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc");  //Madhav Commented
		
		PV_BOOKINGS_MEASURE_INCR_U.unpersist();
		
		System.out.println("Done PV_BOOKINGS_MEASURE_INCR_U");
		
		/********/
		
		/********/
		
		DataFrame PV_PMC_PTNR_MANUAL_OVERRIDE_INCR = hiveContext.sql(PV_PMC_PTNR_MANUAL_OVERRIDE_INCRE);
				
		sc.broadcast(PV_PMC_PTNR_MANUAL_OVERRIDE_INCR);
		
		PV_PMC_PTNR_MANUAL_OVERRIDE_INCR.persist();
		
		PV_PMC_PTNR_MANUAL_OVERRIDE_INCR.take(1);
		
		PV_PMC_PTNR_MANUAL_OVERRIDE_INCR.registerTempTable("PV_PMC_PTNR_MANUAL_OVERRIDE_INCR");
		String maxUpdatedDate_Pv_Manual_Over = hiveContext.sql("select max(from_unixtime(unix_timestamp(EDW_UPDATE_DTM),'yyyy-MM-dd HH:mm:ss')) from PV_PMC_PTNR_MANUAL_OVERRIDE_INCR").takeAsList(1).get(0).getString(0);
		
		DataFrame TOB_INCREMENTAL_NIP_PPPMO = hiveContext.sql(TOBIncrBaseQueries.TOB_INCREMENTAL_NIP_PPPMO);
		TOB_INCREMENTAL_NIP_PPPMO.registerTempTable("TOB_INCREMENTAL_NIP_PPPMO");
		
		DataFrame TOB_INCREMENTAL_UNION = TOB_INCREMENTAL_PBKGSM.unionAll(TOB_INCREMENTAL_NIP_PBKGSCM).unionAll(TOB_INCREMENTAL_NIP_PPPMO);
		
		TOB_INCREMENTAL_UNION.write().mode(SaveMode.Overwrite).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc");
		
		//TOB_INCREMENTAL_NIP_PPPMO.write().mode(SaveMode.Append).parquet("maprfs:/app/DFSimplification/data_enablement/dfprd/baseinc"); //Madhav Commented
		
		PV_PMC_PTNR_MANUAL_OVERRIDE_INCR.unpersist();
		
		System.out.println("Done PV_PMC_PTNR_MANUAL_OVERRIDE_INCR");
		
		/********/
		
		/********/
		
		
		
		try {
			if(maxUpdatedDate_Bkgs_Measure != null){
			jobControl.updateLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_MEASURE",maxUpdatedDate_Bkgs_Measure);
			}else{
			System.out.println("Max last Update Date is NULL for PV_BKGS_MEASURE or No Incremental Records"); 
			}
			if(maxUpdatedDate_Bkgs_Measure_CURR != null) {
			jobControl.updateLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_MEASURE_CURR_QTR",maxUpdatedDate_Bkgs_Measure_CURR);
			}else{
			System.out.println("Max last Update Date is NULL for PV_BKGS_MEASURE_CURR_QTR or No Incremental Records");
			}
			if (maxUpdatedDate_Pv_Manual_Over != null){
			jobControl.updateLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_PMC_PTNR_MANUAL_OVERRIDE",maxUpdatedDate_Pv_Manual_Over);
			}else{
			System.out.println("Max last Update Date is NULL for PV_PMC_PTNR_MANUAL_OVERRIDE or No Incremental Rewcords");
			}
			if (maxUpdatedDate_Bkgs_channel_Measure != null){
				jobControl.updateLastExtractDate("TOTAL_OPPORTUNITY_BASE#PV_BKGS_CHNL_MEASURE",maxUpdatedDate_Bkgs_channel_Measure);
				}else{
				System.out.println("Max last Update Date is NULL for Bkgs_channel_Measure or No Incremental Rewcords");
				}
			

			} catch (Exception e1) {
			System.out.println("Failed to update the last extract date to job control");
			e1.printStackTrace();
			}
		


/*try {
	jobControl.insertJobHistory("TOB_BASE_UNION", getFormattedDate(time_3/1000), getFormattedDate(System.currentTimeMillis()/1000), "SUCCESS", "");
	} catch (Exception e) {
	System.out.println("Failed to insert into Job History Table");
	e.printStackTrace();
	}*/
		
		
	}

}

package com.cisco.eds.df.dataextractor;

public class TOBIncrBaseQueries {
	
	public static String TOB_INCREMENTAL_PVIP = "SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT" 
			+" FROM "+DFConstants.Db+".n_INSTALLED_PRODUCT_incr NIP";
	
	public static String PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR = "select SK_INSTANCE_ID_INT "
			+" from "+DFConstants.Db+".n_SVC_CNTRCT_LN_TECH_SERVICES_incr CL";
			

	public static String PV_SVC_CNTRCT_TECH_SERVICES_INCR = "select bk_service_contract_num"
			+" from "+DFConstants.Db+".n_svc_cntrct_tech_services_incr c";
	

	public static String PV_BKGS_MEASURE_DF1 = "select "
						+" SALES_CHANNEL_CODE,"
						+" ADJUSTMENT_TYPE_CODE,SERVICE_FLG,TRANSACTION_DATETIME,"
						+" BOOKINGS_MEASURE_KEY, BOOKINGS_PROCESS_DATE, SALES_ORDER_LINE_KEY,"
						+" BKGS_MEASURE_TRANS_TYPE_CODE,EDW_UPDATE_DATETIME,sales_territory_key,BK_POS_TRANSACTION_ID_INT"
						+" from sales_tdprod_datalakepvwdb.PV_BKGS_MEASURE,"
						+" (select max(last_extract_date) AS last_extract_date"
						+" from dfprd.JOB_CONTROL_DF_TOB where table_name= 'N_BKGS_MEASURE') A"
						+" where UNIX_TIMESTAMP(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') >A.last_extract_date";
	
	public static String PV_BKGS_MEASURE_DF2 = "select SALES_CHANNEL_CODE,ADJUSTMENT_TYPE_CODE,"
						+" SERVICE_FLG,TRANSACTION_DATETIME,BOOKINGS_MEASURE_KEY, BOOKINGS_PROCESS_DATE, SALES_ORDER_LINE_KEY,"
						+" BKGS_MEASURE_TRANS_TYPE_CODE,EDW_UPDATE_DATETIME,sales_territory_key,BK_POS_TRANSACTION_ID_INT"
						+" from sales_tdprod_datalakepvwdb.PV_BKGS_MEASURE_CURR_QTR,"
						+" (select max(last_extract_date) AS last_extract_date "
						+" from dfprd.JOB_CONTROL_DF_TOB where table_name = 'N_BKGS_MEASURE_CURR_QTR')B"
						+" WHERE UNIX_TIMESTAMP(EDW_UPDATE_DATETIME,'yyyy-MM-dd HH:mm:ss') >B.last_extract_date";
	
	public static String PV_BKGS_MEASURE_INCR = "select "
			+" SALES_ORDER_LINE_KEY,"
			+" BKGS_MEASURE_TRANS_TYPE_CODE"
			+" from "+DFConstants.Db+".PV_BKGS_MEASURE_joinFilter NBM,"
			+" (select max(A.last_extract_date) as last_extract_date from dfprd.JOB_CONTROL_DF_TOB A where A.table_name = 'N_BKGS_MEASURE')abc "
			+" where trim(NBM.BKGS_MEASURE_TRANS_TYPE_CODE) IN  ('ERP','AR','POS') AND NBM.SALES_ORDER_LINE_KEY>0 " 
			+" And UNIX_TIMESTAMP(NBM.EDW_UPDATE_DATETIME ,'yyyy-MM-dd HH:mm:ss') > abc.last_extract_date";


public static String PV_BOOKINGS_MEASURE_INCR_U = "select "
			+" BOOKINGS_MEASURE_KEY,"
			+" BOOKINGS_PROCESS_DATE,"
			+" BKGS_MEASURE_TRANS_TYPE_CODE,"
			+" SALES_ORDER_LINE_KEY"
			+" from "+DFConstants.Db+".PV_BKGS_MEASURE_joinFilter NBM,"
			+" (select min(abc.last_extract_date) AS last_extract_date from (select max(A.last_extract_date) AS "
			+ "last_extract_date  from dfprd.JOB_CONTROL_DF_TOB A where A.table_name = 'N_BKGS_CHNL_MEASURE'"
			+ "UNION ALL "
			+" select max(A.last_extract_date) AS last_extract_date from dfprd.JOB_CONTROL_DF_TOB A "
			+" where A.table_name = 'N_BKGS_MEASURE')abc)aa" 
			+" where UNIX_TIMESTAMP(NBM.EDW_UPDATE_DATETIME ,'yyyy-MM-dd HH:mm:ss') > aa.last_extract_date ";


	public static String PV_PMC_PTNR_MANUAL_OVERRIDE_INCR = "select "
			+" ERP_CUST_ACCOUNT_LOCATION_KEY,"
			+" SOURCE_DELETED_FLG,"
			+" MAPPING_METHOD_CD,"
			+" PERFORMANCE_METRIC_ENGINE_CD"
			+" from "+DFConstants.Db+".PV_PMC_PTNR_MANUAL_OVERRIDE NPMC,"
			+" (select max(A.last_extract_date) as last_extract_date from dfprd.JOB_CONTROL_DF_TOB A where A.table_name = 'N_PMC_PTNR_MANUAL_OVERRIDE')abc"
			+" where "
			+" NPMC.SOURCE_DELETED_FLG = 'N' "
			+" AND NPMC.MAPPING_METHOD_CD = 'MANUAL_OVERRIDE' "
			+" AND NPMC.PERFORMANCE_METRIC_ENGINE_CD = 'INCLUDED' "
			+" AND NPMC.ERP_CUST_ACCOUNT_LOCATION_KEY>0"
			+" AND UNIX_TIMESTAMP(NPMC.EDW_UPDATE_DTM ,'yyyy-MM-dd HH:mm:ss') > abc.last_extract_date";


	public static String PV_POS_TRANSACTION_LINE_INCR = "select "
			+" BK_POS_TRANSACTION_ID_INT"
			+" from "+DFConstants.Db+".PV_POS_TRANSACTION_LINE PTL,"
			+" (select max(A.last_extract_date) as last_extract_date from dfprd.JOB_CONTROL_DF_TOB A where A.table_name = 'N_POS_TRANSACTION_LINE')abc" 
			+" where UNIX_TIMESTAMP(PTL.EDW_UPDATE_DATETIME ,'yyyy-MM-dd HH:mm:ss') > abc.last_extract_date";
	
	
				
			
			//+" UNION"			
			
	/*public static String TOB_INCREMENTAL_PSCLTS = " SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT" 
			+" FROM "+DFConstants.Db+".n_installed_product NIP"
			+" INNER JOIN PV_SVC_CNTRCT_LN_TECH_SERVICES_INCR CL"
			+" ON NIP.SK_INSTANCE_ID_INT=CL.SK_INSTANCE_ID_INT"; */ // Madhav Commented(Marked for deletion)
			
			//+" UNION"
			
		public static String TOB_INCREMENTAL_TOB_PSCTS =	" SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT"
			//+" FROM "+DFConstants.tmp+".total_opportunity_base NIP"
			+" FROM dfprd.total_opportunity_base NIP"
			+" INNER JOIN PV_SVC_CNTRCT_TECH_SERVICES_INCR C"
			+" ON NIP.BK_SERVICE_CONTRACT_NUM=C.BK_SERVICE_CONTRACT_NUM";
			
			//+" UNION"
			
		public static String TOB_INCREMENTAL_PBKGSM = " SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT"
			//+" FROM "+DFConstants.tmp+".total_opportunity_base NIP" 
			+" FROM dfprd.total_opportunity_base NIP"
			+" INNER JOIN PV_BKGS_MEASURE_INCR NBM" 
			+" ON NIP.RU_ORIGINAL_SO_LINE_KEY=NBM.SALES_ORDER_LINE_KEY";
//ru_original_so_ln_rndm_key replace with RU_ORIGINAL_SO_LINE_KEY
			//+" UNION"
			
		public static String TOB_INCREMENTAL_NIP_PBKGSCM = " SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT"
			//+" FROM "+DFConstants.tmp+".total_opportunity_base NIP"
			+" FROM dfprd.total_opportunity_base NIP"
			+" INNER JOIN PV_BOOKINGS_MEASURE_INCR_U NBM" 
			+" ON NIP.RU_ORIGINAL_SO_LINE_KEY=NBM.SALES_ORDER_LINE_KEY"
			+" INNER JOIN "+DFConstants.Db+".PV_BOOKINGS_CHANNEL_MEASURE NBCM"
			+" ON NBM.BOOKINGS_MEASURE_KEY = NBCM.BOOKINGS_MEASURE_KEY"
			+" AND NBM.BOOKINGS_PROCESS_DATE = NBCM.BOOKINGS_PROCESS_DATE"
			+" AND trim(NBM.BKGS_MEASURE_TRANS_TYPE_CODE) = trim(NBCM.BKGS_MEASURE_TRANS_TYPE_CODE)";
			
			//+" UNION"
			
		public static String TOB_INCREMENTAL_NIP_PPPMO = " SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT"
			//+" FROM "+DFConstants.tmp+".total_opportunity_base NIP"
			+" FROM dfprd.total_opportunity_base NIP"
			+" INNER JOIN PV_PMC_PTNR_MANUAL_OVERRIDE_INCR NPMC"
			+" ON  NPMC.ERP_CUST_ACCOUNT_LOCATION_KEY=NIP.BILL_TO_ERP_CUST_ACCT_LOC_KEY";

			//+" UNION"
			
			public static String TOB_INCREMENTAL_NIP_PPTL = " SELECT "
			+" NIP.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT"
			+" FROM "+DFConstants.Db+".n_INSTALLED_PRODUCT NIP"
			+" INNER JOIN PV_POS_TRANSACTION_LINE_INCR PTL"
			+" ON NIP.DU_BK_POS_TRANSACTION_ID_INT = PTL.BK_POS_TRANSACTION_ID_INT";
			
			public static String N_INSTALLED_PRODUCT_temp = " select SK_INSTANCE_ID_INT,"
		 			+" BILL_TO_ERP_CUST_ACCT_LOC_KEY,"
		 			+" RU_ORIGINAL_SO_LINE_KEY,"
		 			+" DU_BK_POS_TRANSACTION_ID_INT,"
		 			+" INSTANCE_STATUS_CD,"
		 			+" GOODS_PRODUCT_KEY,"
		 			+" instance_num,"
		 			+" ip_unit_net_price_local_amt,"
		 			+" ip_unit_list_price_amt,"
		 			+" installed_customer_party_key,"
		 			+" ship_to_erp_cust_acct_loc_key,"
		 			+" du_installation_qty,"
		 			+" du_bk_serial_num,"
		 			+" ip_shipment_confirmed_dtm,"
		 			+" source_order_num,"
		 			+" source_create_dtm,"
		 			+" dd_end_cust_acct_loc_key,"
		 			+" DU_WARRANTY_CNTRCT_LN_START_DT,"
		 			+" attached_eligible_flag,"
		 			+" IP_SALES_TERRITORY_KEY,"
		 			+" INVENTORY_ITEM_ID,"
		 			+" DUP_SERIAL_NUMBER,"
		 			+" INSTANCE_STATUS_ID,"
		 			+" BILL_TO_SITE_USE_ID,"
		 			+" INSTALL_LOCATION_ID,"
		 			+" WARRANTY_TYPE,"
		 			+" SHIP_TO_SITE_USE_ID,"
		 			+" SO_LINE_ID,"
		 			+" IP_TRANSACTIONAL_CURRENCY_CD,"
		 			+" ERP_SELLING_PRICE,"
		 			+" DV_COMPONENT_TYPE_CD,"
		 			+" DU_COMPONENT_INSTANCE_ID_INT," 
		 			+" IP_CUSTOMER_PO_NUM,"
		 			+" DU_WARRANTY_CNTRCT_LN_END_DT,"
		 			+" LZ_LOCATION_TYPE_CD "
		 			+ "from dfprd.n_INSTALLED_PRODUCT ";
			
			//Madhav added
			public static String N_INSTALLED_PRODUCT_INCR_FILTERED = " select SK_INSTANCE_ID_INT,"
		 			+" BILL_TO_ERP_CUST_ACCT_LOC_KEY,"
		 			+" RU_ORIGINAL_SO_LINE_KEY,"
		 			+" DU_BK_POS_TRANSACTION_ID_INT,"
		 			+" INSTANCE_STATUS_CD,"
		 			+" GOODS_PRODUCT_KEY,"
		 			+" instance_num,"
		 			+" ip_unit_net_price_local_amt,"
		 			+" ip_unit_list_price_amt,"
		 			+" installed_customer_party_key,"
		 			+" ship_to_erp_cust_acct_loc_key,"
		 			+" du_installation_qty,"
		 			+" du_bk_serial_num,"
		 			+" ip_shipment_confirmed_dtm,"
		 			+" source_order_num,"
		 			+" source_create_dtm,"
		 			+" dd_end_cust_acct_loc_key,"
		 			+" DU_WARRANTY_CNTRCT_LN_START_DT,"
		 			+" attached_eligible_flag,"
		 			+" IP_SALES_TERRITORY_KEY,"
		 			+" INVENTORY_ITEM_ID,"
		 			+" DUP_SERIAL_NUMBER,"
		 			+" INSTANCE_STATUS_ID,"
		 			+" BILL_TO_SITE_USE_ID,"
		 			+" INSTALL_LOCATION_ID,"
		 			+" WARRANTY_TYPE,"
		 			+" SHIP_TO_SITE_USE_ID,"
		 			+" SO_LINE_ID,"
		 			+" IP_TRANSACTIONAL_CURRENCY_CD,"
		 			+" ERP_SELLING_PRICE,"
		 			+" DV_COMPONENT_TYPE_CD,"
		 			+" DU_COMPONENT_INSTANCE_ID_INT," 
		 			+" IP_CUSTOMER_PO_NUM,"
		 			+" DU_WARRANTY_CNTRCT_LN_END_DT,"
		 			+" LZ_LOCATION_TYPE_CD "
		 			+ "from dfprd.n_INSTALLED_PRODUCT_incr ";
	
			
			public static String TOB_FINAL = " select" 
						+" A.SK_INSTANCE_ID_INT AS SK_INSTANCE_ID_INT,"
					+" COALESCE(NIP_INCR.BILL_TO_ERP_CUST_ACCT_LOC_KEY,NIP.BILL_TO_ERP_CUST_ACCT_LOC_KEY,-999) AS BILL_TO_ERP_CUST_ACCT_LOC_KEY,"
					+" COALESCE(NIP_INCR.RU_ORIGINAL_SO_LINE_KEY,NIP.RU_ORIGINAL_SO_LINE_KEY,-999) AS RU_ORIGINAL_SO_LINE_KEY,"
					+" COALESCE(NIP_INCR.INSTANCE_STATUS_CD,NIP.INSTANCE_STATUS_CD) as INSTANCE_STATUS_CD,"
					+" COALESCE(NIP_INCR.GOODS_PRODUCT_KEY,NIP.GOODS_PRODUCT_KEY,-999) as GOODS_PRODUCT_KEY,"
					+" COALESCE(NIP_INCR.DU_BK_POS_TRANSACTION_ID_INT,NIP.DU_BK_POS_TRANSACTION_ID_INT,-999) as DU_BK_POS_TRANSACTION_ID_INT,"
					+" COALESCE(NIP_INCR.instance_num,NIP.instance_num,-999) as instance_num,"
					+" COALESCE(NIP_INCR.ip_unit_net_price_local_amt,NIP.ip_unit_net_price_local_amt,0) as ip_unit_net_price_local_amt,"
					+" COALESCE(NIP_INCR.ip_unit_list_price_amt,NIP.ip_unit_list_price_amt,0) as ip_unit_list_price_amt,"
					+" COALESCE(NIP_INCR.installed_customer_party_key,NIP.installed_customer_party_key,-999) as installed_customer_party_key,"
					+" COALESCE(NIP_INCR.ship_to_erp_cust_acct_loc_key,NIP.ship_to_erp_cust_acct_loc_key,-999) as ship_to_erp_cust_acct_loc_key,"
					+" COALESCE(NIP_INCR.du_installation_qty,NIP.du_installation_qty,-999) as du_installation_qty,"
					+" COALESCE(NIP_INCR.du_bk_serial_num,NIP.du_bk_serial_num,-999) as du_bk_serial_num,"
					+" COALESCE(NIP_INCR.ip_shipment_confirmed_dtm,NIP.ip_shipment_confirmed_dtm) as ip_shipment_confirmed_dtm,"
					+" COALESCE(NIP_INCR.source_order_num,NIP.source_order_num,-999) as source_order_num,"
					+" COALESCE(NIP_INCR.source_create_dtm,NIP.source_create_dtm) as source_create_dtm,"
					+" COALESCE(NIP_INCR.dd_end_cust_acct_loc_key,NIP.dd_end_cust_acct_loc_key,-999) as dd_end_cust_acct_loc_key,"
					+" COALESCE(NIP_INCR.DU_WARRANTY_CNTRCT_LN_START_DT,NIP.DU_WARRANTY_CNTRCT_LN_START_DT) as DU_WARRANTY_CNTRCT_LN_START_DT,"
					+" COALESCE(NIP_INCR.attached_eligible_flag,NIP.attached_eligible_flag) as attached_eligible_flag,"
					+" COALESCE(NIP_INCR.INVENTORY_ITEM_ID,NIP.INVENTORY_ITEM_ID,-999) as INVENTORY_ITEM_ID,"
					+" COALESCE(NIP_INCR.DUP_SERIAL_NUMBER,NIP.DUP_SERIAL_NUMBER,-999) as DUP_SERIAL_NUMBER,"
					+" COALESCE(NIP_INCR.INSTANCE_STATUS_ID,NIP.INSTANCE_STATUS_ID,-999) as INSTANCE_STATUS_ID,"
					+" COALESCE(NIP_INCR.BILL_TO_SITE_USE_ID,NIP.BILL_TO_SITE_USE_ID,-999) as BILL_TO_SITE_USE_ID,"
					+" COALESCE(NIP_INCR.INSTALL_LOCATION_ID,NIP.INSTALL_LOCATION_ID,-999) as INSTALL_LOCATION_ID,"
					+" COALESCE(NIP_INCR.WARRANTY_TYPE,NIP.WARRANTY_TYPE,-999) as WARRANTY_TYPE,"
					+" COALESCE(NIP_INCR.SHIP_TO_SITE_USE_ID,NIP.SHIP_TO_SITE_USE_ID,-999) as SHIP_TO_SITE_USE_ID,"
					+" COALESCE(NIP_INCR.SO_LINE_ID,NIP.SO_LINE_ID,-999) as SO_LINE_ID,"
					+" COALESCE(NIP_INCR.IP_TRANSACTIONAL_CURRENCY_CD,NIP.IP_TRANSACTIONAL_CURRENCY_CD) as CURRENCY_CODE,"//CURRENCY_CODE
					+" COALESCE(NIP_INCR.ERP_SELLING_PRICE,NIP.ERP_SELLING_PRICE,-999) as ERP_SELLING_PRICE,"	
					+" COALESCE(NIP_INCR.IP_SALES_TERRITORY_KEY,NIP.IP_SALES_TERRITORY_KEY,-999) as IP_SALES_TERRITORY_KEY,"
					+" COALESCE(NIP_INCR.DV_COMPONENT_TYPE_CD,NIP.DV_COMPONENT_TYPE_CD,-999) as ITEM_TYPE_FLAG,"
					+" COALESCE(NIP_INCR.DU_COMPONENT_INSTANCE_ID_INT,NIP.DU_COMPONENT_INSTANCE_ID_INT,-999) as PARENT_INSTANCE_ID,"
					+" COALESCE(NIP_INCR.IP_CUSTOMER_PO_NUM,NIP.IP_CUSTOMER_PO_NUM) as PO_NUMBER,"
					+" COALESCE(NIP_INCR.DU_WARRANTY_CNTRCT_LN_END_DT,NIP.DU_WARRANTY_CNTRCT_LN_END_DT) as WARRANTY_END_DATE,"
					+" COALESCE(NIP_INCR.LZ_LOCATION_TYPE_CD,NIP.LZ_LOCATION_TYPE_CD) as INSTALL_SITE_FLAG"
					+" from tob_incremental_table_distinct A"
					//+" LEFT JOIN dfprd.n_INSTALLED_PRODUCT_INCR NIP_INCR" Madhav Commented
					+" LEFT JOIN N_INSTALLED_PRODUCT_INCR_FILTERED NIP_INCR"
					+" ON A.SK_INSTANCE_ID_INT = NIP_INCR.SK_INSTANCE_ID_INT"
					+" LEFT JOIN N_INSTALLED_PRODUCT_temp NIP"
					+" ON A.SK_INSTANCE_ID_INT = NIP.SK_INSTANCE_ID_INT";
	
	
}

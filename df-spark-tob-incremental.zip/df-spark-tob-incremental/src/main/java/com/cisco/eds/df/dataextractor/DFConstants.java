package com.cisco.eds.df.dataextractor;

public class DFConstants {
	public static final int RNK_VALUE=1;
	
	public static final String Db = "dfprd";
	public static final String svc  = "services_tdprod_datalakepvwdb";
	public static final String sale = "sales_tdprod_datalakepvwdb";
	public static final String ref = "reference_tdprod_datalakepvwdb";
	public static final String tmp = "dfprd";
	
	
}

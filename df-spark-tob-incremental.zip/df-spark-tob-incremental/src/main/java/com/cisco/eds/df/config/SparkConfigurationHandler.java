package com.cisco.eds.df.config;

import java.io.Serializable;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.sql.SQLContext;


public interface SparkConfigurationHandler extends Serializable {

	public void intialize();
	
	public SparkConf getSparkConf();
	
	public JavaSparkContext getSparkContext();
	
	public HiveContext getHiveContext();
	
	public SQLContext getSQLContext();
	
}

package com.cisco.eds.df.main;

import com.cisco.eds.df.config.SparkConfigurationHandler;
import com.cisco.eds.df.config.SparkConfigurationHandlerImpl;
import com.cisco.eds.df.dataprocessor.QueryProcessor;
import com.cisco.eds.df.dataprocessor.QueryProcessorImpl;


public class DFTobIncrementalMain {

	public static void main(String args[]){
		
		SparkConfigurationHandler sparkConfigurationHandler = new SparkConfigurationHandlerImpl();
		sparkConfigurationHandler.intialize();
		
    	QueryProcessor queryProcessor = new QueryProcessorImpl();
    	queryProcessor.processTOBRule(sparkConfigurationHandler.getHiveContext(),sparkConfigurationHandler.getSparkContext());
	
	
	
	}
}

package com.cisco.eds.df.dataprocessor;


import java.text.SimpleDateFormat;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.storage.StorageLevel;

import com.cisco.eds.df.dataextractor.DFConstants;
import com.cisco.eds.df.dataextractor.INCTobQueries;
import com.cisco.eds.df.dataextractor.TOBIncrMergeQueries;


public class QueryProcessorImpl implements QueryProcessor {

	private static final long serialVersionUID = 1L;
	


 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
 
 

	
	@SuppressWarnings("deprecation")
	public void processTOBRule(HiveContext hiveContext, JavaSparkContext sc){
		/***************** *
		 * START- WORK-FLOW.hql*
		 ***************** */
		System.out.println("**********TOB---IncLoad--Base*******");
		//hiveContext.sql("use dfprd");
		System.out.println("starting:"+formatter.format(new java.util.Date()));
		
		DataFrame WI_WORKFLOW_II_PMC_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_PMC_QUOTE);
		WI_WORKFLOW_II_PMC_DF.registerTempTable("WI_WORKFLOW_II_PMC");
		//sc.broadcast(WI_WORKFLOW_II_PMC_DF); 
		WI_WORKFLOW_II_PMC_DF.persist();
		WI_WORKFLOW_II_PMC_DF.take(1);
		
		
		
		DataFrame n_SVC_CNTRCT_LN_OKCK_DF = hiveContext.sql(INCTobQueries.n_SVC_CNTRCT_LN_OKCK_quote);//separate
		n_SVC_CNTRCT_LN_OKCK_DF.registerTempTable("n_SVC_CNTRCT_LN_OKCK_INC");
		hiveContext.sql("drop table if exists dfprd.n_SVC_CNTRCT_LN_OKCK_INC");
		hiveContext.sql("create table dfprd.n_SVC_CNTRCT_LN_OKCK_INC stored as parquet as select * from n_SVC_CNTRCT_LN_OKCK_INC");
		System.out.println("done with n_SVC_CNTRCT_LN_OKCK_INC");
		System.out.println("okck:"+formatter.format(new java.util.Date())); //Madhav uncommented
		
		
	
    	DataFrame WI_LATEST_LINE_IDENTIFICATION_DF = hiveContext.sql(INCTobQueries.WI_LATEST_LINE_IDENTIFICATION_QUOTE);
		WI_LATEST_LINE_IDENTIFICATION_DF.registerTempTable("WI_LATEST_LINE_IDENTIFICATION");
		/*hiveContext.sql("drop table if exists dfprd.WI_LATEST_LINE_IDENTIFICATION");
		hiveContext.sql("create table dfprd.WI_LATEST_LINE_IDENTIFICATION stored as parquet as select * from WI_LATEST_LINE_IDENTIFICATION");*/
		
		//WI_LATEST_LINE_IDENTIFICATION_DF.printSchema();
		
		DataFrame WI_LATEST_LINE_IDENTIFICATION_FLG_DF = hiveContext.sql(INCTobQueries.WI_LATEST_LINE_IDENTIFICATION_FLG_QUOTE);
		WI_LATEST_LINE_IDENTIFICATION_FLG_DF.registerTempTable("WI_LATEST_LINE_IDENTIFICATION_FLG");
		hiveContext.sql("drop table if exists dfprd.WI_LATEST_LINE_IDENTIFICATION_FLG");
		hiveContext.sql("create table dfprd.WI_LATEST_LINE_IDENTIFICATION_FLG stored as parquet as select * from WI_LATEST_LINE_IDENTIFICATION_FLG"); 
		
		/*03-03-2017 Added By Hari to Filter data and store in paraquet*/	
		DataFrame INSTALLED_PRODUCT_FILTERED_DF=hiveContext.sql(INCTobQueries.INSTALLED_PRODUCT_FILTERED);
		INSTALLED_PRODUCT_FILTERED_DF.registerTempTable("INSTALLED_PRODUCT_FILTERED");
		/*03-03-2017 Changes Ended*/
		
		//Madhav Added
		DataFrame PV_SERVICE_QUOTE_LINE_FILTERED = hiveContext.sql(INCTobQueries.PV_SERVICE_QUOTE_LINE_FILTERED);
		PV_SERVICE_QUOTE_LINE_FILTERED.registerTempTable("PV_SERVICE_QUOTE_LINE_FILTERED");
		
        DataFrame WI_WORKFLOW_II_BK_QUOTE_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_BK_QUOTE);
		WI_WORKFLOW_II_BK_QUOTE_DF.registerTempTable("WI_WORKFLOW_II_BK_QUOTE");
		//sc.broadcast(WI_WORKFLOW_II_BK_QUOTE_DF);
		WI_WORKFLOW_II_BK_QUOTE_DF.persist();
		WI_WORKFLOW_II_BK_QUOTE_DF.take(1);
		System.out.println("WI_WORKFLOW_II_BK_QUOTE:"+formatter.format(new java.util.Date()));
		
		/*Changes added By Hari to persist Bookings Join 03-03-2017*/
		DataFrame PV_BKGS_MEASURE_FILTERED = hiveContext.sql(INCTobQueries.PV_BKGS_MEASURE_FILTERED);
		PV_BKGS_MEASURE_FILTERED.registerTempTable("PV_BKGS_MEASURE_FILTERED");
		
		DataFrame PV_BOOKINGS_CHANNEL_MEASURE_FILTERED = hiveContext.sql(INCTobQueries.PV_BOOKINGS_CHANNEL_MEASURE_FILTERED);//separate
		PV_BOOKINGS_CHANNEL_MEASURE_FILTERED.registerTempTable("PV_BOOKINGS_CHANNEL_MEASURE_FILTERED");
		DataFrame PV_BOOKINGS_JOIN=hiveContext.sql(INCTobQueries.PV_BOOKINGS_JOIN);
		PV_BOOKINGS_JOIN.registerTempTable("PV_BOOKINGS_JOIN");
		hiveContext.sql("drop table if exists dfprd.PV_BOOKINGS_JOIN");
		hiveContext.sql("create table dfprd.PV_BOOKINGS_JOIN stored as parquet as select * from PV_BOOKINGS_JOIN");  //Madhav uncommented
		
    	DataFrame WI_WORKFLOW_II_BKGS_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_BKGS_QUOTE);
		WI_WORKFLOW_II_BKGS_DF.registerTempTable("WI_WORKFLOW_II_BKGS");
		
		DataFrame PV_SALES_ORDER_LINE_FILTERED = hiveContext.sql(INCTobQueries.PV_SALES_ORDER_LINE_FILTERED);
		PV_SALES_ORDER_LINE_FILTERED.registerTempTable("PV_SALES_ORDER_LINE_FILTERED");
		
		
		DataFrame WI_WORKFLOW_II_CONTRACT_BKGS_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_CONTRACT_BKGS_QUOTE);
		WI_WORKFLOW_II_CONTRACT_BKGS_DF.registerTempTable("WI_WORKFLOW_II_CONTRACT_BKGS");
		
		DataFrame WI_WORKFLOW_II_CONTRACT_BKGS_RANK = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_CONTRACT_BKGS_RANK);//separate
		WI_WORKFLOW_II_CONTRACT_BKGS_RANK.registerTempTable("WI_WORKFLOW_II_CONTRACT_BKGS_RANK_incr");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_CONTRACT_BKGS_RANK_incr");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_CONTRACT_BKGS_RANK_incr stored as parquet as select * from WI_WORKFLOW_II_CONTRACT_BKGS_RANK_incr");
		System.out.println("contract_bkgs"+formatter.format(new java.util.Date()));
		System.out.println("Done with WI_WORKFLOW_II_CONTRACT_BKGS_RANK_incr");  //Madhav uncommented
		
		DataFrame WI_WORKFLOW_II_PTL_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_PTL_QUOTE);
		WI_WORKFLOW_II_PTL_DF.registerTempTable("WI_WORKFLOW_II_PTL_incr");
		//hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_PTL_incr");
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_II_PTL_incr stored as parquet as select * from WI_WORKFLOW_II_PTL_incr");
		System.out.println("ptl:"+formatter.format(new java.util.Date()));
	
		//WI_WORKFLOW_II_PTL_DF.printSchema();
		
		DataFrame WI_WORKFLOW_III_BILLTO_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_III_BILLTO_QUOTE);
		WI_WORKFLOW_III_BILLTO_DF.registerTempTable("WI_WORKFLOW_III_BILLTO");//saved
		sc.broadcast(WI_WORKFLOW_III_BILLTO_DF);// Added Madhav
		WI_WORKFLOW_III_BILLTO_DF.persist();
		WI_WORKFLOW_III_BILLTO_DF.take(1);
		//hiveContext.sql(" drop table if exists dfprd.WI_WORKFLOW_III_BILLTO");
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_III_BILLTO stored as parquet as select * from WI_WORKFLOW_III_BILLTO"); */
		
		
		
		DataFrame svc_ln_full_DF = hiveContext.sql(INCTobQueries.svc_ln_full_QUOTE);//separate
		svc_ln_full_DF.registerTempTable("svc_ln_full"); //Madhav Uncommented (Move out)
		DataFrame svc_ln_incr_DF = hiveContext.sql(INCTobQueries.svc_ln_incr_QUOTE);//separate
		svc_ln_incr_DF.registerTempTable("svc_ln_incr"); //Madhav added
		
		/*hiveContext.sql("drop table if exists dfprd.svc_ln_full");
		hiveContext.sql("create table dfprd.svc_ln_full stored as parquet as select * from svc_ln_full");
		System.out.println("svc_ln_full:"+formatter.format(new java.util.Date())); */
		
		DataFrame svc_tech_full_DF = hiveContext.sql(INCTobQueries.svc_tech_full_QUOTE);//separate
		svc_tech_full_DF.registerTempTable("svc_tech_full"); //Madhav Uncommented (Move out)
		
		DataFrame svc_tech_incr_DF = hiveContext.sql(INCTobQueries.svc_tech_incr_QUOTE);
		svc_tech_incr_DF.registerTempTable("svc_tech_incr"); //Madhav added (Move out)
		
		/*hiveContext.sql("drop table if exists dfprd.svc_tech_full");
		hiveContext.sql("create table dfprd.svc_tech_full stored as parquet as select * from svc_tech_full");
		System.out.println("svc_tech_full:"+formatter.format(new java.util.Date()));*/
		
		DataFrame WI_WORKFLOW_II_TEMP_DF_CVD_1 = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_TEMP_QUOTE_CVD_1);
		WI_WORKFLOW_II_TEMP_DF_CVD_1.registerTempTable("WI_WORKFLOW_II_TEMP_DF_CVD_1");
	//	hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_TEMP_QUOTE_CVD_1");
	//	hiveContext.sql("create table dfprd.WI_WORKFLOW_II_TEMP_QUOTE_CVD_1 stored as parquet as select * from WI_WORKFLOW_II_TEMP_DF_CVD_1");
		System.out.println("WI_WORKFLOW_II_TEMP_DF_CVD_1:"+formatter.format(new java.util.Date()));
		
		DataFrame WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO=hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO);
		WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO.registerTempTable("WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO");
		//hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_TEMP_incr"); Vamsi Commented
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_II_TEMP_incr stored as parquet as select * from WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO"); //Vamsi Commented
		DataFrame WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO=hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO);
		WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO.registerTempTable("WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO");
		//hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_TEMP_incr select * from WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO"); //Vamsi Commented
		DataFrame WI_WORKFLOW_II_TEMP_incr_temp = WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_GREATER_THAN_ZERO.unionAll(WI_WORKFLOW_II_TEMP_QUOTE_CVD_2_LESS_THAN_ZERO);
		
		System.out.println("WI_WORKFLOW_II_TEMP_incr"+formatter.format(new java.util.Date()));
		
		DataFrame TOB_INCREMENTAL_TABLE_FILTERED = hiveContext.sql(INCTobQueries.TOB_INCREMENTAL_TABLE_FILTERED);
		TOB_INCREMENTAL_TABLE_FILTERED.registerTempTable("TOB_INCREMENTAL_TABLE_FILTERED");
		//TOB_INCREMENTAL_TABLE_FILTERED.printSchema();
		/*DataFrame N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED = hiveContext.sql(INCTobQueries.N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED);
		N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED.registerTempTable("N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED");
		
		DataFrame N_SVC_CNTRCT_LN_TECH_SERVICES_INCR_FILTERED = hiveContext.sql(INCTobQueries.N_SVC_CNTRCT_LN_TECH_SERVICES_INCR_FILTERED);
		N_SVC_CNTRCT_LN_TECH_SERVICES_INCR_FILTERED.registerTempTable("N_SVC_CNTRCT_LN_TECH_SERVICES_INCR_FILTERED"); */ //Madhav Commented (marked for deletion)
		
		DataFrame WI_WORKFLOW_II_TEMP_NCVRD_QUOTE = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_TEMP_NCVRD_QUOTE);
		WI_WORKFLOW_II_TEMP_NCVRD_QUOTE.registerTempTable("WI_WORKFLOW_II_TEMP_NCVRD_QUOTE");
		//WI_WORKFLOW_II_TEMP_NCVRD_QUOTE.printSchema();
		//hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_TEMP_incr select * from WI_WORKFLOW_II_TEMP_NCVRD_QUOTE"); //Vamsi Commented
		DataFrame WI_WORKFLOW_II_TEMP_incr = WI_WORKFLOW_II_TEMP_incr_temp.unionAll(WI_WORKFLOW_II_TEMP_NCVRD_QUOTE);

		WI_WORKFLOW_II_TEMP_incr.registerTempTable("WI_WORKFLOW_II_TEMP_incr"); //Vamsi added
		
		
		WI_WORKFLOW_II_TEMP_incr.persist().take(1); //Vamsi added Madhav Commented
		
		System.out.println("WI_WORKFLOW_II_TEMP_NCVRD_QUOTE"+formatter.format(new java.util.Date()));
		
		

	    DataFrame WI_WORKFLOW_II_STEP_1_D_NONZERO = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_1_QUOTE_NONZERO);
	    WI_WORKFLOW_II_STEP_1_D_NONZERO.registerTempTable("WI_WORKFLOW_II_STEP_1_D_NONZERO");
	    hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_1_INCR");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_1_INCR stored as parquet as select * from WI_WORKFLOW_II_STEP_1_D_NONZERO");
		
	    
	    DataFrame WI_WORKFLOW_II_STEP_1_DF_ZERO = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_1_QUOTE_ZERO);
	    WI_WORKFLOW_II_STEP_1_DF_ZERO.registerTempTable("WI_WORKFLOW_II_STEP_1_DF_ZERO");
	    hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_1_INCR select * from WI_WORKFLOW_II_STEP_1_DF_ZERO");
	    System.out.println("WI_WORKFLOW_II_STEP_1"+formatter.format(new java.util.Date()));

	    WI_WORKFLOW_II_TEMP_incr.unpersist(); //Vamsi added 
	    
	    
		DataFrame WI_PARTNER_RTM_MEASURE_RNWD_DF = hiveContext.sql(INCTobQueries.WI_PARTNER_RTM_MEASURE_RNWD_QUOTE);
		WI_PARTNER_RTM_MEASURE_RNWD_DF.registerTempTable("WI_PARTNER_RTM_MEASURE_RNWD");
		
		
		DataFrame WI_WORKFLOW_II_STEP_II_DF_CVD = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_II_QUOTE_CVD);
		WI_WORKFLOW_II_STEP_II_DF_CVD.registerTempTable("WI_WORKFLOW_II_STEP_II_DF_CVD");
		hiveContext.sql("drop table if exists dfprd.wi_workflow_ii_step_ii_incr");
		//hiveContext.sql("create table dfprd.wi_workflow_ii_step_ii_incr stored as parquet as select * from WI_WORKFLOW_II_STEP_II_DF_CVD"); Vamsi Commented
		
		DataFrame WI_WORKFLOW_II_STEP_II_DF_NCVD = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_II_QUOTE_NCVD);
		WI_WORKFLOW_II_STEP_II_DF_NCVD.registerTempTable("WI_WORKFLOW_II_STEP_II_DF_NCVD");
		//hiveContext.sql("insert into table dfprd.wi_workflow_ii_step_ii_incr select * from WI_WORKFLOW_II_STEP_II_DF_NCVD"); Vamsi Commented
		
		DataFrame wi_workflow_ii_step_ii_incr = WI_WORKFLOW_II_STEP_II_DF_CVD.unionAll(WI_WORKFLOW_II_STEP_II_DF_NCVD);
		
		wi_workflow_ii_step_ii_incr.persist().take(1);//Vamsi added
		
		wi_workflow_ii_step_ii_incr.registerTempTable("wi_workflow_ii_step_ii_incr");
		
		//WI_WORKFLOW_II_STEP_II_DF_NCVD.printSchema();
		System.out.println("wi_workflow_ii_step_ii_incr"+formatter.format(new java.util.Date()));
		
		WI_WORKFLOW_II_BK_QUOTE_DF.unpersist(); 
		
		DataFrame n1_DF = hiveContext.sql(INCTobQueries.n1_temp);
		n1_DF.registerTempTable("N1");
		sc.broadcast(n1_DF);
		n1_DF.persist().take(1);//commented
		
		
		DataFrame wff_DF = hiveContext.sql(INCTobQueries.wff_temp);
		wff_DF.registerTempTable("WFF"); 
		
		DataFrame WI_PARTNER_RTM_MEASURE_PRIOR_DF = hiveContext.sql(INCTobQueries.WI_PARTNER_RTM_MEASURE_PRIOR_QUOTE);
		WI_PARTNER_RTM_MEASURE_PRIOR_DF.registerTempTable("WI_PARTNER_RTM_MEASURE_PRIOR_incr");
		//hiveContext.sql("drop table if exists dfprd.WI_PARTNER_RTM_MEASURE_PRIOR_incr");
		//hiveContext.sql("create table dfprd.WI_PARTNER_RTM_MEASURE_PRIOR_incr stored as parquet as select * from WI_PARTNER_RTM_MEASURE_PRIOR_DF");
		
		System.out.println("Done with WI_PARTNER_RTM_MEASURE_PRIOR_incr");
		
    	DataFrame WI_WORKFLOW_II_STEP_III_DF_GREATER_THAN_ZERO = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_III_QUOTE_GREATER_TAHN_ZERO);
    	WI_WORKFLOW_II_STEP_III_DF_GREATER_THAN_ZERO.registerTempTable("WI_WORKFLOW_II_STEP_III_DF_GREATER_THAN_ZERO"); //Madhav added
		DataFrame WI_WORKFLOW_II_STEP_III_DF_LESS_THAN_ZERO = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_III_QUOTE_LESS_THAN_ZERO);
		WI_WORKFLOW_II_STEP_III_DF_LESS_THAN_ZERO.registerTempTable("WI_WORKFLOW_II_STEP_III_DF_LESS_THAN_ZERO"); //Madhav added
		DataFrame WI_WORKFLOW_II_STEP_III_DF=WI_WORKFLOW_II_STEP_III_DF_GREATER_THAN_ZERO.unionAll(WI_WORKFLOW_II_STEP_III_DF_LESS_THAN_ZERO);
		WI_WORKFLOW_II_STEP_III_DF.registerTempTable("WI_WORKFLOW_II_STEP_III_incr"); 
		
		//hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_III_incr");
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_III_incr stored as parquet as select * from WI_WORKFLOW_II_STEP_III_DF_GREATER_THAN_ZERO");
		//hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_III_incr select * from WI_WORKFLOW_II_STEP_III_DF_LESS_THAN_ZERO");
		
		//WI_WORKFLOW_II_STEP_III_DF.printSchema();
		//System.out.println("done with WI_WORKFLOW_II_STEP_III_incr.....");
	
	
		DataFrame WI_WORKFLOW_II_STEP_IV_DF_CVD = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_IV_QUOTE_CVD);
		WI_WORKFLOW_II_STEP_IV_DF_CVD.registerTempTable("WI_WORKFLOW_II_STEP_IV_incr");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_IV_incr");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_IV_incr stored as parquet as select * from WI_WORKFLOW_II_STEP_IV_incr");
		
		DataFrame WI_WORKFLOW_II_STEP_IV_DF_NCVD = hiveContext.sql(INCTobQueries.WI_WORKFLOW_II_STEP_IV_QUOTE_NCVD);
		WI_WORKFLOW_II_STEP_IV_DF_NCVD.registerTempTable("WI_WORKFLOW_II_STEP_IV_DF_NCVD");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_IV_incr select * from WI_WORKFLOW_II_STEP_IV_DF_NCVD");
		System.out.println("WI_WORKFLOW_II_STEP_IV_DF_NCVD"+formatter.format(new java.util.Date()));
		System.out.println("Done with WI_WORKFLOW_II_STEP_IV_incr");
		
		wi_workflow_ii_step_ii_incr.unpersist(); //Vamsi added
		
		WI_WORKFLOW_II_PMC_DF.unpersist();
	

    	DataFrame WI_WORKFLOW_III_POS_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_III_POS_QUOTE);
		//WI_WORKFLOW_III_POS_DF.write().partitionBy("BK_POS_TRANSACTION_ID_INT");
		WI_WORKFLOW_III_POS_DF.registerTempTable("WI_WORKFLOW_III_POS");
		sc.broadcast(WI_WORKFLOW_III_POS_DF);
		WI_WORKFLOW_III_POS_DF.persist();//commented
		WI_WORKFLOW_III_POS_DF.take(1);
		//hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_POS");
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_III_POS stored as parquet as select * from WI_WORKFLOW_III_POS");
		
	
		DataFrame WI_WORKFLOW_III_STEP1_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_III_STEP1_QUOTE);
		WI_WORKFLOW_III_STEP1_DF.registerTempTable("WI_WORKFLOW_III_STEP1");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP1");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP1 stored as parquet as select * from WI_WORKFLOW_III_STEP1");
		
		DataFrame WI_WORKFLOW_III_STEP_II_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_III_STEP_II_QUOTE);
		WI_WORKFLOW_III_STEP_II_DF.registerTempTable("WI_WORKFLOW_III_STEP_II");
		
		//WI_WORKFLOW_III_STEP_II_DF.write().partitionBy("SVC_BILL_ERP_CUST_ACCT_LOC_KEY");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP_II");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP_II stored as parquet as select * from WI_WORKFLOW_III_STEP_II");
		
		
		DataFrame WI_WORKFLOW_III_STEP_III_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_III_STEP_III_QUOTE);
		WI_WORKFLOW_III_STEP_III_DF.registerTempTable("WI_WORKFLOW_III_STEP_III_incr");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP_III_incr");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP_III_incr stored as parquet as select * from WI_WORKFLOW_III_STEP_III_incr");
		System.out.println("WI_WORKFLOW_III_STEP_III_incr"+formatter.format(new java.util.Date()));
		WI_WORKFLOW_III_BILLTO_DF.unpersist();
		
		
		DataFrame PV_CHNL_BKG_AND_PTR_TO_RTM_MPG = hiveContext.sql("select * from "+DFConstants.svc+".PV_CHNL_BKG_AND_PTR_TO_RTM_MPG LKPPOS");
		
		sc.broadcast(PV_CHNL_BKG_AND_PTR_TO_RTM_MPG);

		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG.persist();//commented
		
		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG.take(1);
		
		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG.registerTempTable("PV_CHNL_BKG_AND_PTR_TO_RTM_MPG");
					
		
		
		DataFrame WI_WORKFLOW_RTM_STEP1_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_RTM_STEP1_QUOTE);
		WI_WORKFLOW_RTM_STEP1_DF.registerTempTable("WI_WORKFLOW_RTM_STEP1");
		//hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_RTM_STEP1");
		//hiveContext.sql("create table dfprd.WI_WORKFLOW_RTM_STEP1 stored as parquet as select * from WI_WORKFLOW_RTM_STEP1");
		
		DataFrame WI_SW_HW_IDENTIFICATION_DF = hiveContext.sql(INCTobQueries.WI_SW_HW_IDENTIFICATION_QUOTE);
		WI_SW_HW_IDENTIFICATION_DF.registerTempTable("WI_SW_HW_IDENTIFICATION");
		sc.broadcast(WI_SW_HW_IDENTIFICATION_DF);
		WI_SW_HW_IDENTIFICATION_DF.persist();//commented
		WI_SW_HW_IDENTIFICATION_DF.take(1);
		
		
		DataFrame WI_WORKFLOW_RTM_STEP2_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_RTM_STEP2_QUOTE);
		WI_WORKFLOW_RTM_STEP2_DF.registerTempTable("WI_WORKFLOW_RTM_STEP2_QUOTE");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_RTM_STEP2_incr_sample ");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_RTM_STEP2_incr_sample stored as parquet as select * from WI_WORKFLOW_RTM_STEP2_QUOTE");
		System.out.println("WI_WORKFLOW_RTM_STEP2_incr_sample"+formatter.format(new java.util.Date()));
		System.out.println("Done with WI_WORKFLOW_RTM_STEP2_incr"); 
		
		DataFrame WI_WORKFLOW_RTM_STEP3_DF = hiveContext.sql(INCTobQueries.WI_WORKFLOW_RTM_STEP3_QUOTE);
		WI_WORKFLOW_RTM_STEP3_DF.registerTempTable("WI_WORKFLOW_RTM_STEP3_incr");
		
		
		DataFrame WI_WORKFLOW_RTM_STEP4 = hiveContext.sql(INCTobQueries.WI_WORKFLOW_RTM_STEP4);
        WI_WORKFLOW_RTM_STEP4.registerTempTable("WI_WORKFLOW_RTM_STEP4");
        
        
        DataFrame WI_WORKFLOW_RTM_STEP4_FILTERED = hiveContext.sql(INCTobQueries.WI_WORKFLOW_RTM_STEP4_FILTERED);
         WI_WORKFLOW_RTM_STEP4_FILTERED.registerTempTable("WI_WORKFLOW_RTM_STEP4_FILTERED");
        
        //Latest Line Flag Retro Update
        hiveContext.sql(INCTobQueries.WI_LATEST_LINE_HIST_RETRO_UPDATE);
        
        //Write Incremental data
        hiveContext.sql("insert into table "+DFConstants.Db+".total_opportunity_base_incr select * from WI_WORKFLOW_RTM_STEP4");

		
	}
	
}

package com.cisco.eds.df.main;
import com.cisco.eds.df.config.SparkConfigurationHandler;
import com.cisco.eds.df.config.SparkConfigurationHandlerImpl;
import com.cisco.eds.df.dataprocessor.TOBIncrQueryProcessorImpl;
public class DFTobUnionMain {

	public static void main(String[] args) {
		SparkConfigurationHandler sparkConfigurationHandler = new SparkConfigurationHandlerImpl();
		sparkConfigurationHandler.intialize();
		
		
		TOBIncrQueryProcessorImpl incrDataGenerator = new TOBIncrQueryProcessorImpl();
    	incrDataGenerator.generateBaseTOBIncrData(sparkConfigurationHandler.getHiveContext(),sparkConfigurationHandler.getSparkContext());

	}

}

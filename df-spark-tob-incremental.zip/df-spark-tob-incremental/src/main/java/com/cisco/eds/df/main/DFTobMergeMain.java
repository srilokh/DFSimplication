package com.cisco.eds.df.main;

import com.cisco.eds.df.config.SparkConfigurationHandler;
import com.cisco.eds.df.config.SparkConfigurationHandlerImpl;
import com.cisco.eds.df.dataprocessor.TOBIncrMergeQueryProcessorImpl;


public class DFTobMergeMain {

	public static void main(String[] args) {
		SparkConfigurationHandler sparkConfigurationHandler = new SparkConfigurationHandlerImpl();
		sparkConfigurationHandler.intialize();
		
		TOBIncrMergeQueryProcessorImpl incrMergeDataGenerator = new TOBIncrMergeQueryProcessorImpl();
    	incrMergeDataGenerator.generateBaseTOBIncrMergeData(sparkConfigurationHandler.getHiveContext(),sparkConfigurationHandler.getSparkContext());

	}

}

package com.cisco.eds.df.dataprocessor;

import java.io.Serializable;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.hive.HiveContext;


public interface QueryProcessor extends Serializable {

	
	public void processTOBRule(HiveContext hiveContext, JavaSparkContext sc);

}

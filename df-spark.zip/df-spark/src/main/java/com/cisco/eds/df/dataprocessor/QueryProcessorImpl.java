package com.cisco.eds.df.dataprocessor;


import java.text.SimpleDateFormat;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;
import org.apache.spark.storage.StorageLevel;

import com.cisco.eds.df.dataextractor.DFTobQueries;




public class QueryProcessorImpl implements QueryProcessor {

	private static final long serialVersionUID = 1L;

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	@SuppressWarnings("deprecation")
	public void processTOBRule(HiveContext hiveContext,JavaSparkContext sc){
		/***************** *
		 * START- WORK-FLOW.hql*
		 *
		 ***************** */
/*		System.out.println("starting:"+formatter.format(new java.util.Date()));
		
    	DataFrame WI_LATEST_LINE_IDENTIFICATION_DF = hiveContext.sql(DFTobQueries.WI_LATEST_LINE_IDENTIFICATION_QUOTE);
		WI_LATEST_LINE_IDENTIFICATION_DF.registerTempTable("WI_LATEST_LINE_IDENTIFICATION");
		
		DataFrame WI_LATEST_LINE_IDENTIFICATION_FLAG_DF = hiveContext.sql(DFTobQueries.WI_LATEST_LINE_IDENTIFICATION_FLAG_QUOTE);
		WI_LATEST_LINE_IDENTIFICATION_FLAG_DF.registerTempTable("WI_LATEST_LINE_IDENTIFICATION_FLAG");
		hiveContext.sql("drop table if exists dfprd.WI_LATEST_LINE_IDENTIFICATION_FLAG");
		hiveContext.sql("create table dfprd.WI_LATEST_LINE_IDENTIFICATION_FLAG stored as parquet as select * from WI_LATEST_LINE_IDENTIFICATION_FLAG");
	
		DataFrame WI_SW_HW_IDENTIFICATION = hiveContext.sql(DFTobQueries.WI_SW_HW_IDENTIFICATION_QUOTE);
		WI_SW_HW_IDENTIFICATION.registerTempTable("WI_SW_HW_IDENTIFICATION");
		sc.broadcast(WI_SW_HW_IDENTIFICATION);
		WI_SW_HW_IDENTIFICATION.persist();
		WI_SW_HW_IDENTIFICATION.take(1);*/
		
		/*DataFrame PV_BKGS_MEASURE_DF1 = hiveContext.sql(DFTobQueries.PV_BKGS_MEASURE_DF1);
		PV_BKGS_MEASURE_DF1.registerTempTable("PV_BKGS_MEASURE_DF1");
		
		DataFrame PV_BKGS_MEASURE_DF2 = hiveContext.sql(DFTobQueries.PV_BKGS_MEASURE_DF2);
		PV_BKGS_MEASURE_DF2.registerTempTable("PV_BKGS_MEASURE_DF2");
		
		PV_BKGS_MEASURE_DF1.unionAll(PV_BKGS_MEASURE_DF2).registerTempTable("PV_BKGS_MEASURE_UNION");
		hiveContext.sql("drop table if exists dfprd.PV_BKGS_MEASURE");
		hiveContext.sql("create table dfprd.PV_BKGS_MEASURE stored as parquet as select * from PV_BKGS_MEASURE_UNION");*/
		
/*		DataFrame WI_WORKFLOW_II_BK_QUOTE_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_BK_QUOTE);
		WI_WORKFLOW_II_BK_QUOTE_DF.registerTempTable("WI_WORKFLOW_II_BK_QUOTE");
		
		DataFrame PV_BKGS_MEASURE_FILTERED_DF = hiveContext.sql(DFTobQueries.PV_BKGS_MEASURE_FILTERED);
		PV_BKGS_MEASURE_FILTERED_DF.registerTempTable("PV_BKGS_MEASURE_FILTERED");
		
		DataFrame PV_BOOKINGS_CHANNEL_MEASURE_FILTERED_DF = hiveContext.sql(DFTobQueries.PV_BOOKINGS_CHANNEL_MEASURE_FILTERED);
		PV_BOOKINGS_CHANNEL_MEASURE_FILTERED_DF.registerTempTable("PV_BOOKINGS_CHANNEL_MEASURE_FILTERED");
		
		DataFrame PV_MT_PARTNER_HIERARCHY_FILTERED_DF = hiveContext.sql(DFTobQueries.PV_MT_PARTNER_HIERARCHY_FILTERED);
		PV_MT_PARTNER_HIERARCHY_FILTERED_DF.registerTempTable("PV_MT_PARTNER_HIERARCHY_FILTERED");
		
		/*DataFrame BKGS_MSR_BKNGS_CHNL_MSR_JOINED_DF = hiveContext.sql(DFTobQueries.BKGS_MSR_BKNGS_CHNL_MSR_JOINED);
		BKGS_MSR_BKNGS_CHNL_MSR_JOINED_DF.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_JOINED");
		hiveContext.sql("drop table if exists dfprd.BKGS_MSR_BKNGS_CHNL_MSR_JOINED");
		hiveContext.sql("create table dfprd.BKGS_MSR_BKNGS_CHNL_MSR_JOINED stored as parquet as select * from BKGS_MSR_BKNGS_CHNL_MSR_JOINED");*/
		
		/*DataFrame PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS_DF = hiveContext.sql(DFTobQueries.PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS);
		PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS_DF.registerTempTable("PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS");
		
		sc.broadcast(PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS_DF);
		PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS_DF.persist();
		PV_BOOKINGS_CHANNEL_MEASURE_SKWD_KEYS_DF.take(1);
		
		DataFrame PV_MT_PARTNER_HIERARCHY_SKWD_DF = hiveContext.sql(DFTobQueries.PV_MT_PARTNER_HIERARCHY_SKWD);
		PV_MT_PARTNER_HIERARCHY_SKWD_DF.registerTempTable("PV_MT_PARTNER_HIERARCHY_SKWD");
		
		sc.broadcast(PV_MT_PARTNER_HIERARCHY_SKWD_DF);
		PV_MT_PARTNER_HIERARCHY_SKWD_DF.persist();
		PV_MT_PARTNER_HIERARCHY_SKWD_DF.take(1);
		
		DataFrame BKGS_MSR_BKNGS_CHNL_MSR_JOINED_SKWD_DF = hiveContext.sql(DFTobQueries.BKGS_MSR_BKNGS_CHNL_MSR_JOINED_SKWD);
		BKGS_MSR_BKNGS_CHNL_MSR_JOINED_SKWD_DF.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_JOINED_SKWD");
		
		DataFrame BKGS_MSR_BKNGS_CHNL_MSR_JOINED_NON_SKWD_DF = hiveContext.sql(DFTobQueries.BKGS_MSR_BKNGS_CHNL_MSR_JOINED_NON_SKWD);
		BKGS_MSR_BKNGS_CHNL_MSR_JOINED_NON_SKWD_DF.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_JOINED_NON_SKWD");
		
		DataFrame BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_NON_SKWD_DF = hiveContext.sql(DFTobQueries.BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_NON_SKWD);
		BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_NON_SKWD_DF.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_NON_SKWD_DF");
		
		DataFrame BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_SKWD_DF = hiveContext.sql(DFTobQueries.BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_SKWD);
		BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_SKWD_DF.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED_SKWD_DF");
		
		
		DataFrame BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED = hiveContext.sql("select * from BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED");
		BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED.registerTempTable("BKGS_MSR_BKNGS_CHNL_MSR_MT_PRTNR_HR_JOINED");
		
    	DataFrame WI_WORKFLOW_II_BKGS_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_BKGS_QUOTE);
		WI_WORKFLOW_II_BKGS_DF.registerTempTable("WI_WORKFLOW_II_BKGS");
		hiveContext.cacheTable("WI_WORKFLOW_II_BKGS");
		
		DataFrame PV_SALES_ORDER_LINE_FILTERED = hiveContext.sql(DFTobQueries.PV_SALES_ORDER_LINE_FILTERED);
		PV_SALES_ORDER_LINE_FILTERED.registerTempTable("PV_SALES_ORDER_LINE_FILTERED");
		
		DataFrame WI_WORKFLOW_II_CONTRACT_BKGS_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_CONTRACT_BKGS_QUOTE);
		WI_WORKFLOW_II_CONTRACT_BKGS_DF.registerTempTable("WI_WORKFLOW_II_CONTRACT_BKGS");*/
		
		/*DataFrame WI_WORKFLOW_II_CONTRACT_BKGS_RANK = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_CONTRACT_BKGS_RANK);
		WI_WORKFLOW_II_CONTRACT_BKGS_RANK.registerTempTable("WI_WORKFLOW_II_CONTRACT_BKGS_RANK");
		/*Added by hari*/
		/*hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_CONTRACT_BKGS_RANK");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_CONTRACT_BKGS_RANK stored as parquet as select * from WI_WORKFLOW_II_CONTRACT_BKGS_RANK");*/
		/*added by hari ended */
		
		/*DataFrame WI_WORKFLOW_II_PMC_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_PMC_QUOTE);
		WI_WORKFLOW_II_PMC_DF.registerTempTable("WI_WORKFLOW_II_PMC");
		sc.broadcast(WI_WORKFLOW_II_PMC_DF);
		WI_WORKFLOW_II_PMC_DF.persist();
		WI_WORKFLOW_II_PMC_DF.take(1);
		
		
		DataFrame WI_WORKFLOW_II_PTL_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_PTL_QUOTE);
		WI_WORKFLOW_II_PTL_DF.registerTempTable("WI_WORKFLOW_II_PTL_full");
		
    	DataFrame WI_WORKFLOW_III_BILLTO_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_BILLTO_QUOTE);
		WI_WORKFLOW_III_BILLTO_DF.registerTempTable("WI_WORKFLOW_III_BILLTO");   
		sc.broadcast(WI_WORKFLOW_III_BILLTO_DF);
		WI_WORKFLOW_III_BILLTO_DF.persist();
		WI_WORKFLOW_III_BILLTO_DF.take(1);
		
		
	/*	DataFrame WI_WORKFLOW_II_TEMP_CVRD_QUOTE = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_TEMP_CVRD_QUOTE);
		WI_WORKFLOW_II_TEMP_CVRD_QUOTE.registerTempTable("WI_WORKFLOW_II_TEMP_CVRD_QUOTE");

		DataFrame n_installed_product_FILTERED = hiveContext.sql(DFTobQueries.n_installed_product_FILTERED);
		n_installed_product_FILTERED.registerTempTable("n_installed_product_FILTERED");
		
		DataFrame N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED = hiveContext.sql(DFTobQueries.N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED);
		N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED.registerTempTable("N_SVC_CNTRCT_LN_TECH_SERVICES_FILTERED");
		
		DataFrame WI_WORKFLOW_II_TEMP_NCVRD_QUOTE = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_TEMP_NCVRD_QUOTE);
		WI_WORKFLOW_II_TEMP_NCVRD_QUOTE.registerTempTable("WI_WORKFLOW_II_TEMP_NCVRD_QUOTE");
		
		/*hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_TEMP_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_TEMP_full stored as parquet as select * from WI_WORKFLOW_II_TEMP_CVRD_QUOTE");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_TEMP_full select * from WI_WORKFLOW_II_TEMP_NCVRD_QUOTE");
		
		DataFrame WI_WORKFLOW_II_PTL_broad = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_PTL_bc);
		WI_WORKFLOW_II_PTL_broad.registerTempTable("WI_WORKFLOW_II_PTL_broad");
		
	    DataFrame N_INSTALLED_PRODUCT_DF = hiveContext.sql(DFTobQueries.N_INSTALLED_PRODUCT_temp);
	    N_INSTALLED_PRODUCT_DF.registerTempTable("N_INSTALLED_PRODUCT_temp");
	    
	    DataFrame N_INSTALLED_PRODUCT_temp_NONZERO = hiveContext.sql(DFTobQueries.N_INSTALLED_PRODUCT_temp_NONZERO);
	    N_INSTALLED_PRODUCT_temp_NONZERO.registerTempTable("N_INSTALLED_PRODUCT_temp_NONZERO");
	    
	    DataFrame N_INSTALLED_PRODUCT_temp_ZERO = hiveContext.sql(DFTobQueries.N_INSTALLED_PRODUCT_temp_ZERO);
	    N_INSTALLED_PRODUCT_temp_ZERO.registerTempTable("N_INSTALLED_PRODUCT_temp_ZERO");
	    
	    DataFrame WI_WORKFLOW_II_PTL_FILTERED = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_PTL_FILTERED);
	    WI_WORKFLOW_II_PTL_FILTERED.registerTempTable("WI_WORKFLOW_II_PTL_FILTERED");
	    
	    DataFrame WI_WORKFLOW_II_STEP_1_TMP1_QUOTE = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_1_TMP1_QUOTE);
	    WI_WORKFLOW_II_STEP_1_TMP1_QUOTE.registerTempTable("WI_WORKFLOW_II_STEP_1_TMP1_QUOTE");*/
	    
	   /* hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_PTL_MERGED");
	    hiveContext.sql("create table dfprd.WI_WORKFLOW_II_PTL_MERGED stored as parquet as select * from WI_WORKFLOW_II_STEP_1_TMP1_QUOTE");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_PTL_MERGED select * from N_INSTALLED_PRODUCT_temp_ZERO");
	    
    	DataFrame WI_WORKFLOW_II_STEP_1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_1_QUOTE);
    	WI_WORKFLOW_II_STEP_1.registerTempTable("WI_WORKFLOW_II_STEP_1");
    	hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_1_full");
	    hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_1_full stored as parquet as select * from WI_WORKFLOW_II_STEP_1");*/
/*		
		DataFrame WI_PARTNER_RTM_MEASURE_RNWD_DF = hiveContext.sql(DFTobQueries.WI_PARTNER_RTM_MEASURE_RNWD_QUOTE);
		WI_PARTNER_RTM_MEASURE_RNWD_DF.registerTempTable("WI_PARTNER_RTM_MEASURE_RNWD_full");
		hiveContext.sql("drop table if exists dfprd.WI_PARTNER_RTM_MEASURE_RNWD_full");
	    hiveContext.sql("create table dfprd.WI_PARTNER_RTM_MEASURE_RNWD_full stored as parquet as select * from WI_PARTNER_RTM_MEASURE_RNWD_full");
		
		DataFrame WI_WORKFLOW_II_STEP_II_QUOTE = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_QUOTE);
		WI_WORKFLOW_II_STEP_II_QUOTE.registerTempTable("WI_WORKFLOW_II_STEP_II_QUOTE");
		
		DataFrame WI_WORKFLOW_II_STEP_I_NONZERO = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_I_NONZERO);
		WI_WORKFLOW_II_STEP_I_NONZERO.registerTempTable("WI_WORKFLOW_II_STEP_I_NONZERO");
		
		DataFrame WI_WORKFLOW_II_STEP_I_ZERO = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_I_ZERO);
		WI_WORKFLOW_II_STEP_I_ZERO.registerTempTable("WI_WORKFLOW_II_STEP_I_ZERO");
		
		DataFrame WI_WORKFLOW_II_STEP_II_TMP2 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_TMP2);
		WI_WORKFLOW_II_STEP_II_TMP2.registerTempTable("WI_WORKFLOW_II_STEP_II_TMP2");
		
		DataFrame WI_WORKFLOW_II_STEP_II_TMP1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_TMP1);
		WI_WORKFLOW_II_STEP_II_TMP1.registerTempTable("WI_WORKFLOW_II_STEP_II_TMP1");*/
		
		/*hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_II_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_II_full stored as parquet as select * from WI_WORKFLOW_II_STEP_II_TMP1");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_II_full select * from WI_WORKFLOW_II_STEP_II_TMP2");*/
		
		/*DataFrame WI_WORKFLOW_II_STEP_II_SKWD_KEYS = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_II_SKWD_KEYS.registerTempTable("WI_WORKFLOW_II_STEP_II_SKWD_KEYS");
		
		sc.broadcast(WI_WORKFLOW_II_STEP_II_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_II_SKWD_KEYS.persist();
		WI_WORKFLOW_II_STEP_II_SKWD_KEYS.take(1);
		
		DataFrame WI_WORKFLOW_II_BKGS_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_BKGS_SKWD);
		WI_WORKFLOW_II_BKGS_SKWD.registerTempTable("WI_WORKFLOW_II_BKGS_SKWD");
		
		sc.broadcast(WI_WORKFLOW_II_BKGS_SKWD);
		WI_WORKFLOW_II_BKGS_SKWD.persist();
		WI_WORKFLOW_II_BKGS_SKWD.take(1);
		
		DataFrame WI_WORKFLOW_II_STEP_II_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_SKWD);
		WI_WORKFLOW_II_STEP_II_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_II_SKWD");
		
		DataFrame WI_WORKFLOW_II_STEP_II_NON_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_II_NON_SKWD);
		WI_WORKFLOW_II_STEP_II_NON_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_II_NON_SKWD");

		DataFrame WI_WORKFLOW_II_STEP_III_TMP1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_III_TMP1);
		WI_WORKFLOW_II_STEP_III_TMP1.registerTempTable("WI_WORKFLOW_II_STEP_III_TMP1");
		
		DataFrame WI_WORKFLOW_II_STEP_III_TMP2 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_III_TMP2);
		WI_WORKFLOW_II_STEP_III_TMP2.registerTempTable("WI_WORKFLOW_II_STEP_III_TMP2");*/

		/*hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_III_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_III_full stored as parquet as select * from WI_WORKFLOW_II_STEP_III_TMP1");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_III_full select * from WI_WORKFLOW_II_STEP_III_TMP2");*/
/*		
		DataFrame n1_DF = hiveContext.sql(DFTobQueries.n1_temp);
		n1_DF.registerTempTable("N1");
		sc.broadcast(n1_DF);
		n1_DF.persist();
		n1_DF.take(1);

		DataFrame wff_DF = hiveContext.sql(DFTobQueries.wff_temp);
		wff_DF.registerTempTable("WFF");
		
		DataFrame WI_PARTNER_RTM_MEASURE_PRIOR_DF = hiveContext.sql(DFTobQueries.WI_PARTNER_RTM_MEASURE_PRIOR_QUOTE);
		WI_PARTNER_RTM_MEASURE_PRIOR_DF.registerTempTable("WI_PARTNER_RTM_MEASURE_PRIOR_full");
		hiveContext.sql("drop table if exists dfprd.WI_PARTNER_RTM_MEASURE_PRIOR_full");
	    hiveContext.sql("create table dfprd.WI_PARTNER_RTM_MEASURE_PRIOR_full stored as parquet as select * from WI_PARTNER_RTM_MEASURE_PRIOR_full");
		
		/*DataFrame SrvcPmc_df = hiveContext.sql(DFTobQueries.SrvcPmc);
		sc.broadcast(SrvcPmc_df);
		SrvcPmc_df.persist();
		SrvcPmc_df.take(1);
		SrvcPmc_df.registerTempTable("srvc_pmc_cast");*/
		
		/*DataFrame cntrBuk_df = hiveContext.sql(DFTobQueries.cntrBuk);
		cntrBuk_df.registerTempTable("cntrBuk_cast");
		sc.broadcast(cntrBuk_df);
		cntrBuk_df.persist();
		cntrBuk_df.take(1);*/
		/*commented by hari
		//Handling skweness for STEP IV join 1
		DataFrame WI_WORKFLOW_II_STEP_III_SKWD_KEYS = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_III_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_III_SKWD_KEYS.registerTempTable("WI_WORKFLOW_II_STEP_III_SKWD_KEYS");
		
		sc.broadcast(WI_WORKFLOW_II_STEP_III_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_III_SKWD_KEYS.persist();
		WI_WORKFLOW_II_STEP_III_SKWD_KEYS.take(1);
		
		DataFrame WI_WORKFLOW_II_STEP_III_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_III_SKWD);
		WI_WORKFLOW_II_STEP_III_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_III_SKWD");
		
		sc.broadcast(WI_WORKFLOW_II_STEP_III_SKWD);
		WI_WORKFLOW_II_STEP_III_SKWD.persist();
		WI_WORKFLOW_II_STEP_III_SKWD.take(1);
		
		DataFrame WI_WORKFLOW_II_STEP_III_NON_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_III_NON_SKWD);
		WI_WORKFLOW_II_STEP_III_NON_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_III_NON_SKWD");

		DataFrame WI_WORKFLOW_II_STEP_IV_TMP1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP1);
		WI_WORKFLOW_II_STEP_IV_TMP1.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP1");
		DataFrame WI_WORKFLOW_II_STEP_IV_TMP2 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP2);
		WI_WORKFLOW_II_STEP_IV_TMP2.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP2");

		/*hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_IV_TMP");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_IV_TMP stored as parquet as select * from WI_WORKFLOW_II_STEP_IV_TMP1");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_IV_TMP select * from WI_WORKFLOW_II_STEP_IV_TMP2");*/
		/*comment added by hari
		//Handling skweness for STEP IV join 2
		DataFrame WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS");
		
		sc.broadcast(WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS.persist();
		WI_WORKFLOW_II_STEP_IV_TMP_SKWD_KEYS.take(1);
		
		DataFrame WI_WORKFLOW_II_STEP_IV_TMP_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP_SKWD);
		WI_WORKFLOW_II_STEP_IV_TMP_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP_SKWD");
		
		DataFrame WI_WORKFLOW_II_STEP_IV_TMP_NON_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP_NON_SKWD);
		WI_WORKFLOW_II_STEP_IV_TMP_NON_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP_NON_SKWD");

		DataFrame WI_WORKFLOW_II_STEP_IV_TMP3 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP3);
		WI_WORKFLOW_II_STEP_IV_TMP3.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP3");
		
		DataFrame WI_WORKFLOW_II_STEP_IV_TMP4 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_TMP4);
		WI_WORKFLOW_II_STEP_IV_TMP4.registerTempTable("WI_WORKFLOW_II_STEP_IV_TMP4");

		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_IV_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_IV_full stored as parquet as select * from WI_WORKFLOW_II_STEP_IV_TMP3");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_IV_full select * from WI_WORKFLOW_II_STEP_IV_TMP4");
		*/
		/*Added by hari 07-03-2017*/
		
		/*DataFrame WI_WORKFLOW_II_STEP_IV_DF_CVD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_QUOTE_CVD);
		WI_WORKFLOW_II_STEP_IV_DF_CVD.registerTempTable("WI_WORKFLOW_II_STEP_IV_full");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_II_STEP_IV_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_II_STEP_IV_full stored as parquet as select * from WI_WORKFLOW_II_STEP_IV_full");
		
		DataFrame WI_WORKFLOW_II_STEP_IV_DF_NCVD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_QUOTE_NCVD);
		WI_WORKFLOW_II_STEP_IV_DF_NCVD.registerTempTable("WI_WORKFLOW_II_STEP_IV_DF_NCVD");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_II_STEP_IV_full select * from WI_WORKFLOW_II_STEP_IV_DF_NCVD");
		System.out.println("WI_WORKFLOW_II_STEP_IV_DF_NCVD"+formatter.format(new java.util.Date()));
		System.out.println("Done with WI_WORKFLOW_II_STEP_IV_full");*/
		
		/*Added by hari 07-03-2017*/
		
		//WI_WORKFLOW_II_STEP_IV_TMP3.write().saveAsTable("dfprd.WI_WORKFLOW_II_STEP_IV_full");
		//WI_WORKFLOW_II_STEP_IV_TMP4.write().mode(SaveMode.Append).saveAsTable("dfprd.WI_WORKFLOW_II_STEP_IV_full"); 
		
		
		//Handling skweness for WI_WORKFLOW_III_STEP1 join
		DataFrame WI_WORKFLOW_II_STEP_IV_SKWD_KEYS = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_IV_SKWD_KEYS.registerTempTable("WI_WORKFLOW_II_STEP_IV_SKWD_KEYS");
		
		sc.broadcast(WI_WORKFLOW_II_STEP_IV_SKWD_KEYS);
		WI_WORKFLOW_II_STEP_IV_SKWD_KEYS.persist();
		WI_WORKFLOW_II_STEP_IV_SKWD_KEYS.take(1);
		
		DataFrame WI_WORKFLOW_II_STEP_IV_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_SKWD);
		WI_WORKFLOW_II_STEP_IV_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_IV_SKWD");
		
		DataFrame WI_WORKFLOW_II_STEP_IV_NON_SKWD = hiveContext.sql(DFTobQueries.WI_WORKFLOW_II_STEP_IV_NON_SKWD);
		WI_WORKFLOW_II_STEP_IV_NON_SKWD.registerTempTable("WI_WORKFLOW_II_STEP_IV_NON_SKWD");

		DataFrame WI_WORKFLOW_III_STEP1_TMP1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_STEP1_TMP1);
		WI_WORKFLOW_III_STEP1_TMP1.registerTempTable("WI_WORKFLOW_III_STEP1_TMP1");
		DataFrame WI_WORKFLOW_III_STEP1_TMP2 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_STEP1_TMP2);
		WI_WORKFLOW_III_STEP1_TMP2.registerTempTable("WI_WORKFLOW_III_STEP1_TMP2");

		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP1_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP1_full stored as parquet as select * from WI_WORKFLOW_III_STEP1_TMP1");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_III_STEP1_full select * from WI_WORKFLOW_III_STEP1_TMP2");
		
		DataFrame WI_WORKFLOW_III_POS_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_POS_QUOTE);
		WI_WORKFLOW_III_POS_DF.registerTempTable("WI_WORKFLOW_III_POS_full");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_POS_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_POS_full stored as parquet as select * from WI_WORKFLOW_III_POS_full");
		
		//sc.broadcast(WI_WORKFLOW_III_POS_DF);
		//WI_WORKFLOW_III_POS_DF.persist();
		//WI_WORKFLOW_III_POS_DF.take(1);
		
		DataFrame WI_WORKFLOW_III_STEP_II_TMP1 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_STEP_II_TMP1);
		WI_WORKFLOW_III_STEP_II_TMP1.registerTempTable("WI_WORKFLOW_III_STEP_II_TMP1_DF");
		
		DataFrame WI_WORKFLOW_III_STEP_II_TMP2 = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_STEP_II_TMP2);
		WI_WORKFLOW_III_STEP_II_TMP2.registerTempTable("WI_WORKFLOW_III_STEP_II_TMP2_DF");
		
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP_II_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP_II_full stored as parquet as select * from WI_WORKFLOW_III_STEP_II_TMP1_DF");
		hiveContext.sql("insert into table dfprd.WI_WORKFLOW_III_STEP_II_full select * from WI_WORKFLOW_III_STEP_II_TMP2_DF"); 
		
		DataFrame WI_WORKFLOW_III_STEP_III = hiveContext.sql(DFTobQueries.WI_WORKFLOW_III_STEP_III_QUOTE);
		WI_WORKFLOW_III_STEP_III.registerTempTable("WI_WORKFLOW_III_STEP_III_full");
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_III_STEP_III_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_III_STEP_III_full stored as parquet as select * from WI_WORKFLOW_III_STEP_III_full");
		
		
		DataFrame PV_CHNL_BKG_AND_PTR_TO_RTM_MPG_DF = hiveContext.sql("select ROUTE_TO_MARKET_CD,BK_POS_FLG,BK_ROUTE_TO_MARKET_TYPE_CD,BK_HYBRID_CHANNEL_BOOKING_CD,BK_PARTNER_TYPE_CD from dfprd.PV_CHNL_BKG_AND_PTR_TO_RTM_MPG");
		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG_DF.registerTempTable("PV_CHNL_BKG_AND_PTR_TO_RTM_MPG");
		sc.broadcast(PV_CHNL_BKG_AND_PTR_TO_RTM_MPG_DF);
		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG_DF.persist();
		PV_CHNL_BKG_AND_PTR_TO_RTM_MPG_DF.take(1);
		
		
		DataFrame WI_WORKFLOW_RTM_STEP1_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_RTM_STEP1_QUOTE);
		WI_WORKFLOW_RTM_STEP1_DF.registerTempTable("WI_WORKFLOW_RTM_STEP1_full");
		
		DataFrame WI_WORKFLOW_RTM_STEP2_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_RTM_STEP2_QUOTE); 
		WI_WORKFLOW_RTM_STEP2_DF.registerTempTable("WI_WORKFLOW_RTM_STEP2_full");
		
		hiveContext.sql("drop table if exists dfprd.WI_WORKFLOW_RTM_STEP2_full");
		hiveContext.sql("create table dfprd.WI_WORKFLOW_RTM_STEP2_full stored as parquet as select * from WI_WORKFLOW_RTM_STEP2_full"); 
		
	//	sc.broadcast(WI_LATEST_LINE_IDENTIFICATION_FLAG_DF);
	//	WI_LATEST_LINE_IDENTIFICATION_FLAG_DF.persist();
	//	WI_LATEST_LINE_IDENTIFICATION_FLAG_DF.take(1); 
		
		DataFrame WI_WORKFLOW_TOB_FINAL_DF = hiveContext.sql(DFTobQueries.WI_WORKFLOW_TOB_FINAL_QUOTE);
		WI_WORKFLOW_TOB_FINAL_DF.registerTempTable("total_opportunity_base_history");
		
		hiveContext.sql("drop table if exists dfprd.total_opportunity_base_history");
		hiveContext.sql("create table dfprd.total_opportunity_base_history stored as parquet as select * from total_opportunity_base_history"); 
    	
    	DataFrame WI_WORKFLOW_TOB_FINAL_history = hiveContext.sql(DFTobQueries.WI_WORKFLOW_TOB_FINAL_history);
    	WI_WORKFLOW_TOB_FINAL_history.registerTempTable("WI_WORKFLOW_TOB_FINAL_history");
    	hiveContext.sql("drop table if exists dfprd.total_opportunity_base");
    	hiveContext.sql("create table dfprd.total_opportunity_base stored as parquet as select * from WI_WORKFLOW_TOB_FINAL_history");
		
    	System.out.println("Ending:"+formatter.format(new java.util.Date()));
		
		
	}
	
}

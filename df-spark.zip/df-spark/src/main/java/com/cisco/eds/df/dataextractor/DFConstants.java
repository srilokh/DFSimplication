package com.cisco.eds.df.dataextractor;

public class DFConstants {
	public static final int RNK_VALUE=1;
	public static final String dv3_schema="services_tdtest_datalakepvwdb_ts3";
	public static final String bcm = "reference_tdtest_datalakepvwdb_tst.PV_BOOKINGS_CHANNEL_MEASURE";
	public static final String mph_schema = "reference_tdtest_datalakepvwdb_ts3";
	public static final String sales_schema = "sales_tdtest_datalakepvwdb_ts3";
	public static final String order_schema = "sales_datalakepvwdb_tst";
	public static final String ptl_schema = "reference";
	public static final String epb_schema = "services_DATALAKEPVWDB_TS1";
	public static final String db = "service_ibsa";
	
	
}

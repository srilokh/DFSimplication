package com.cisco.eds.df.config;
import com.cisco.eds.df.dataextractor.DFTobQueries;
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(DFTobQueries.WI_WORKFLOW_II_STEP_IV_QUOTE_CVD);
	}

}

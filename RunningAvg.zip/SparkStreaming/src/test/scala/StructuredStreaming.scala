import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext



object StructuredStreaming extends App{
  val spark = SparkSession
  .builder()
  .master("local[2]")
  .appName("simple structured streaming")
  .getOrCreate()
  import spark.implicits._
  
  val lines = spark.readStream.csv("file:///C:/Users/smoram/workspace/SparkStreaming/spark-warehouse/get.csv")
  val words = lines.as[String].flatMap(_.split(" "))
  val wc = words.groupBy("name").count()
  
}
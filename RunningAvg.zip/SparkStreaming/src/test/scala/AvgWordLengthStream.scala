import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.dstream.DStream.toPairDStreamFunctions
object AvgWordLengthStream {
  def main(args: Array[String]) {

    val sparkConf = new SparkConf().setAppName("AverageStream").setMaster("local[2]")
    // Create the Streamingcontext
    val ssc = new StreamingContext(sparkConf, Seconds(10))
    val lines = ssc.textFileStream("file://c:/test/input/")
    val words = lines.flatMap(_.split(","))
    val wordCounts = words.map(x => (x, 1)).reduceByKey(_ + _)
    //wordCounts.print()
    val avgs = wordCounts.map { case (word, count) => (word, count / word.length.toDouble) }
    println("my averages are:")
    avgs.print()
    ssc.start()
    ssc.awaitTermination()

  }
}


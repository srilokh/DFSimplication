import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object Overall extends App{
  val conf = new SparkConf().setAppName("sample example").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val file = sc.textFile("C:/Users/smoram/workspace/SparkStreaming/sample.txt")
  val line = file.flatMap(x => x.split(" "))
  val words = line.map(word => (word,1))
  val sum = words.reduceByKey((x,y) => x + y)
  sum.collect()
  
}
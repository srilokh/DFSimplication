import org.apache.spark.sql.SparkSession.builder
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext

object Sample extends App{
  val conf = new SparkConf().setAppName("sample Program").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val spark = SparkSession
  .builder()
  .appName("Spark SQL basic example")
  .getOrCreate()
  val df = spark.read.json("file:///C:/test/inputs/")
  //df.show()
  df.select("countrycode", "countryname","lendprojectcost","url").show()
  
  //df.groupBy("countryname").count().show()
  //df.filter(df.col("grantamt").gt(50000)).show()
 // df.filter("grantamt > 50000").show()
  //df.createOrReplaceTempView("people")
  //val dfsql = spark.sql("select * from people").show()
  //val exp = spark.sql("select max(grantamt) from people").show()
  //val avgg = spark.sql("select avg(grantamt) from people").show()
  //val meann = spark.sql("select mean(grantamt) from people").show()
  //df.sort("countryname").dropDuplicates().show()
 // df.createOrReplaceTempView("people")
  //val sf = spark.sql("select countrycode,countryname from people").where("countrycode = 'IN'")
  //sf.show()
  
  //val peopleFormat = spark.read.format("json").load("file:///C:/test/inputs/*.json")
  //peopleFormat.select("countryname", "countrycode").write.format("csv").save("xyz.csv")
  //spark.catalog.refreshTable("people")
  
  

  
  
  
  
}
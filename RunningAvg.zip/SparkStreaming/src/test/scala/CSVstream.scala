import org.apache.spark.streaming.StreamingContext
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SQLImplicits

object QueryCSVData {
  def main(args: Array[String]) {
    
   val conf = new SparkConf().setAppName("CSV Data").setMaster("local[2]") 
   val sc = new SparkContext(conf)
   val sqlContext = new org.apache.spark.sql.SQLContext(sc)   
   val df = sqlContext.load("file://c:/test/input/*.csv")
   val rootLogger = Logger.getRootLogger()
   rootLogger.setLevel(Level.ERROR) 
   rootLogger.removeAllAppenders()
   //dataframe operations
   println ("####### Data Frame Operations #############")
   df.printSchema()
   df.filter("amountPaid>=500").filter("itemId>=3").show()
    //SQL operations
    println ("####### SQL Operations ######################")
    df.registerTempTable("sales") 
    val aggDF = sqlContext.sql("select sum(amountPaid) from sales")
    val item3 = sqlContext.sql("select sum(amountPaid) from sales where itemId>=3")
    println("Amount paid === "+aggDF.collectAsList())
    println("Item Id 3 ==== "+item3.collectAsList())
    
  }
}

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SQLImplicits
import org.apache.spark.sql._
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.types.{ StructType, StructField, StringType, IntegerType };
import org.apache.hadoop.fs.Path

object MovingAvg {
  def main(args: Array[String]): Unit = {
    println("Java Version:" + System.getProperty("java.version"))
    println("Java Home:" + System.getProperties().getProperty("java.home"))

  if (args.length == 0) {
      println("Args: <numberOfSeconds>" +  "<runLocal>" )
      return
    }

    val numberOfSeconds = args(0).toInt
    val inputPath="C:\\Users\\smoram\\workspace\\SparkStreaming\\input"
    val runLocal = args(1).equalsIgnoreCase("l")
   
    println("numberOfSeconds:" + numberOfSeconds)
    println("runLocal:" + runLocal)

    val sc:SparkContext = if (runLocal) {
      val sparkConfig = new SparkConf()
      //sparkConfig.set("spark.broadcast.compress", "false")
    //  sparkConfig.set("spark.shuffle.compress", "false")
      //sparkConfig.set("spark.shuffle.spill.compress", "false")
      new SparkContext("local[*]", "TableStatsSinglePathMain", sparkConfig)
    } else {
    val sparkConf = new SparkConf().setAppName("Running Average").setMaster("local[4]")
      new SparkContext(sparkConf)
    }
    val ssc = new StreamingContext(sc, Seconds(numberOfSeconds))
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)   
    val customDatahubSchema=StructType(Array(StructField("itemId", StringType, true),
    StructField("amountPaid", StringType, true)))
    println(inputPath)
    val df = sqlContext.load("com.databricks.spark.csv",schema = customDatahubSchema, Map("path" -> inputPath, "header" -> "false"))
   //dataframe operations
   println ("####### Data Frame Operations #############")
   
   df.printSchema()
   df.filter("amountPaid>=500").filter("itemId>=3").show()
    //SQL operations
    println ("####### SQL Operations ######################")
    df.registerTempTable("sales") 
    val aggDF = sqlContext.sql("select sum(amountPaid) from sales")
    val item3 = sqlContext.sql("select sum(amountPaid) from sales where itemId>=3")
    println("Amount paid === "+aggDF.collectAsList())
    println("Item Id 3 ==== "+item3.collectAsList())
    
  }
}
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Dataset
import org.apache.spark.sql._


object Sample1 extends App{
  val conf = new SparkConf().setAppName("DataSets").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val spark = SparkSession
  .builder()
  .getOrCreate()
  //case class Person(name: String, age: Long)
  import spark.implicits._
  //val caseClassDS = Seq(Person("sri",25)).toDS().show()
  //val arr = Seq(1,2,3).toDS()
 // arr.map(_ + 1).show()
  
  
  case class Weather(id: Int, location: String, Temp: Long)
  //val w = Seq(Weather(1,"NJ",65),Weather(2,"MO",72),Weather(3,"CA",75)).toDS()
  val path = "file:///C:/test/inputs/file.txt"
  val peopleDS = spark.read.textFile(path).as[Weather]
 // w.show()
 // w.filter(x => {x.Temp > 70}).show()
  //val ease = w.select("id", "location","Temp").where($"Temp" > 70)
  peopleDS.show()
  //val fina = ease.rdd.collect()
}
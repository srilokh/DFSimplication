import org.apache.spark.sql._
import org.apache.spark.sql.catalyst.parser.ParseException

object HiveSupport extends App{
  //case class Record(key: Int, value: String)
  val warehouselocation = "C:/Users/smoram/workspace/SparkStreaming/spark-warehouse/"
  val spark = SparkSession
  .builder()
  .master("local[2]")
  .appName("spark hive example")
  .config("spark.sql.warehouse.dir",warehouselocation )
  .enableHiveSupport()
  .getOrCreate()
  import spark.implicits._
  import spark.sqlContext._
  sql("create table if not exists car_all(key INT, value String) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','")
  sql("load data local inpath 'file:///C:/test/inputs/carr.txt' into table car_all")
  sql("SELECT * FROM car_all").show()
  sql("select COUNT(*) FROM car_all").show()
}
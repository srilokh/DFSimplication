import org.apache.spark.sql.SparkSession

object HiveSample extends App{
  val warehouse = "C:/Users/smoram/workspace/SparkStreaming/spark-warehouse/"
  val spark = SparkSession
  .builder()
  .enableHiveSupport()
  .master("local[2]")
  .appName("basic hive")
  .config("spark.sql.warehouse.dir",warehouse)
  .getOrCreate()
  import spark.implicits._
  import spark.sqlContext._
  sql("create table IF NOT EXISTS lift(id Int, name String,temp Int, state String) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','")
  sql("LOAD DATA LOCAL INPATH 'C:/Users/smoram/workspace/SparkStreaming/spark-warehouse/get.csv' into table lift")
  sql("select * from lift").show() 
  sql("select count(1) from lift").show()
}
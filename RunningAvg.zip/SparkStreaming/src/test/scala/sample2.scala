import org.apache.spark.sql.SparkSession.Builder
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
object sample2 extends App{
  val conf = new SparkConf().setAppName("sample program").setMaster("local[2]")
  val sc = new SparkContext(conf)
  val spark = SparkSession
  .builder()
  .getOrCreate()
  import spark.implicits._
 //val df = Seq(1,2,3).toDS()
 //val ki = df.map(_ + 1)
 //ki.show()
  //case class people(id: Int, name: String, temp: Int,state: String)
  //val path = "file:///C:/Users/smoram/workspace/SparkStreaming/spark-warehouse/"
 // val data = spark.read.csv(path).as[people]
  //data.createTempView("people")
  //spark.sql("select * from people").show()
  var n = 100
  val squareDF = spark.sparkContext.makeRDD(1 to n).map { x => (x, x * x) }.toDF("value","square")
  squareDF.show()
  
  
}
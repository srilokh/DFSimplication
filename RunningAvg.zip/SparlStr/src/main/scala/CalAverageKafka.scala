
import kafka.serializer.StringDecoder
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka.KafkaUtils
import org.apache.spark.rdd.RDD



/**
 * Counts words in new text files created in the given directory
 * Usage: HdfsWordCount <directory>
 *   <directory> is the directory that Spark Streaming will use to find and read new text files.
 *
 * To run this on your local machine on directory `localdir`, run this example
 *    $ bin/run-example \
 *       org.apache.spark.examples.streaming.HdfsWordCount localdir
 *
 * Then create a text file in `localdir` and the words in the file will get counted.
 */
object CalAverage {
  def main(args: Array[String]) {

    //StreamingExamples.setStreamingLogLevels()
    val sparkConf = new SparkConf().setAppName("CalAverage").setMaster("local[2]")
    // Create the context
    val ssc = new StreamingContext(sparkConf, Seconds(10))
    //eds-kafka-dev-001:9092,eds-kafka-dev-002:9092,eds-kafka-dev-003:9092,eds-kafka-dev-004:9092
    //eds-zk-dev-01:2181
    val kafkaParams = Map[String, String](
        "metadata.broker.list" -> "eds-kafka-dev-001:9092",
      "bootstrap.servers" -> "eds-kafka-dev-001:9092",
      "group.id" -> "test",
      "auto.offset.reset" -> "smallest"     )
// 
     // "value.deserializer" -> classOf[StringDeserializer],
      //"enable.auto.commit" -> (false: java.lang.Boolean)
     
    //  val topics = Array("sparktesttopic")
    val topicsSet = "sparktesttopic".split(",").toSet
    // Create the FileInputDStream on the directory and use the
    // stream to count words in new files created
    //val lines = KafkaUtils.createDirectStream(jssc, locationStrategy, consumerStrategy)
    //val lines = KafkaUtils.createDirectStream[String, String](ssc,  PreferConsistent,  Subscribe[String, String](topics, kafkaParams))
    val lines = KafkaUtils.createDirectStream[String,String, StringDecoder,StringDecoder](ssc, kafkaParams, topicsSet)
    lines.print()
    val words = lines.map(_._2).flatMap(_.split(",")).window(Minutes(30), Seconds(10))
    // Convert RDDs of the words DStream to DataFrame and run SQL query
    words.foreachRDD { (rdd: RDD[String], time: Time) =>
      // Get the singleton instance of SparkSession
      val spark = SparkSessionSingleton.getInstance(rdd.sparkContext.getConf)
      import spark.implicits._

      // Convert RDD[String] to RDD[case class] to DataFrame
      val wordsDataFrame = rdd.map(w => Record(w)).toDF()

      // Creates a temporary view using the DataFrame
      wordsDataFrame.createOrReplaceTempView("words")

      // Do word count on table using SQL and print it
      val wordCountsDataFrame =
        spark.sql("select avg(*) Average from words")
      println(s"========= $time =========")
      wordCountsDataFrame.show()
    }

    ssc.start()
    ssc.awaitTermination()
  }
}

/** Case class for converting RDD to DataFrame */
case class Record(wordt: String)

/** Lazily instantiated singleton instance of SparkSession */
object SparkSessionSingleton {

  @transient private var instance: SparkSession = _

  def getInstance(sparkConf: SparkConf): SparkSession = {
    if (instance == null) {
      instance = SparkSession
        .builder
        .config(sparkConf)
        .getOrCreate()
    }
    instance
  }
}
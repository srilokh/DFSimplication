import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.math3.random.RandomDataGenerator;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;


public class SimpleKafkaProducer implements Serializable{

     
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
        
		Properties props = new Properties();
        props.put("bootstrap.servers","eds-kafka-dev-001.cisco.com:9092");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("request.required.acks", "1");
      //  props.put("retries", 0);
        //props.put("batch.size", 16384);
       // props.put("linger.ms", 1);
       // props.put("buffer.memory", 33554432);
       // props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        //props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		KafkaProducer<String,String> producer = new KafkaProducer<String,String>(props);

        ProducerRecord<String,String> producerRecord;
		
          
          
          String topic="sparktesttopic";
         try{ 
        	while(true){
        		Map<String, String> data = prepareJsonData();
		       	  for (Map.Entry<String, String> entry : data.entrySet()) {
		              String key = entry.getKey();
		              String value = entry.getValue();
		              //System.out.println(key);
		              //System.out.println(value);
		              producerRecord	= new ProducerRecord<String,String>(topic, key, value);
			          producer.send(producerRecord);
			          System.out.println("Data Produced Key: "+key+" Value: "+value);
			          Thread.sleep(1000);
		         } 
        	}
         }catch(Exception e ){
        	 e.printStackTrace();
         }
         producer.close();
          
	}
   
    private static Map<String,String> prepareJsonData(){
    	 RandomDataGenerator rand = new RandomDataGenerator();
          Map<String,String>  dataMap =new HashMap<String,String>();
          dataMap.put("smoram-12345", ""+rand.nextInt(200,900)+","+rand.nextInt(200,900)+"");
  return dataMap;
     }

} 
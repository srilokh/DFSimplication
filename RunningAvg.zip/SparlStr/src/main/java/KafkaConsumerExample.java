import java.util.Arrays;
import java.util.Properties;
import java.util.UUID;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class KafkaConsumerExample {
	
	public static void main(String[] args) {
		 Properties props = new Properties();
		 props.put("bootstrap.servers", "eds-kafka-dev-001.cisco.com:9092");
		props.put("group.id", "test");
	     props.put("enable.auto.commit", "true");
	     props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
	     props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
	     props.put(ConsumerConfig.GROUP_ID_CONFIG, UUID.randomUUID().toString());
	     props.put(ConsumerConfig.CLIENT_ID_CONFIG, "your_client_id");
	     props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
	     
	    /* KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
	     
	     //subsribe to the topic
	     consumer.subscribe(Arrays.asList("sparktesttopic"));
	     while (true) {
		     try{	
		    	 //Keep polling the topic every 5 seconds
		         ConsumerRecords<String, String> records = consumer.poll(5000);
		         System.out.println("records");
		         for (ConsumerRecord<String, String> record : records)
		             System.out.println("value = " + record.value());
		     }
		     catch (Exception e) {
		    		
	             e.printStackTrace();
		     }
	     }*/
		

	}
}